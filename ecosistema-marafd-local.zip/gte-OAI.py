# ToolKit gte-OAI.py by MARAFd - TECNOLOGIA PARA LA GESTION DE FONDOS DOCUMENTALES DIGITALES
# GTE-OAI.py (Genera Tesauro Estandar y Tesauro OAI-PMH)
# https://calentamientoglobalacelerado.net/MARAFd/
# PROYECTO: MARAFd - GESTION INTELIGENTE DE FONDOS DOCUMENTALES DIGITALES BASADA EN TESAURO                     
# OPEN SOURCE SOLUTION by RAFAEL LOMENA VARO - MARAF SOFT 1993 ©© 2026    
# Generador de Código: ChatGPT, modificado por Claude
# Idea original y supervisiOn: Rafael Lomena - MaRaF SOFT
# Ecosistema tecnologia: MARAFd (c)(c) 2026

# En Windows instala Python antes de ejecutar esta herramienta
#
# Desde Windows CMD..
#
# descarga:
#       curl -o python-3.12.2-amd64.exe https://www.python.org/ftp/python/3.12.2/python-3.12.2-amd64.exe

# instalar:
#       python-3.12.2-amd64.exe InstallAllUsers=1 PrependPath=1 Include_test=0
#
# .. y la libreria windows-curses desde consola:
#       pip install windows-curses
#
# Verifica instalacion:
#       python --version
#       pip --version

#!/usr/bin/env python3
# -*- coding: utf-8 -*-


from __future__ import annotations

import argparse
import codecs
import csv
import mimetypes
import re
import sys
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from datetime import UTC, date, datetime
from io import StringIO
from pathlib import Path, PurePosixPath
from urllib.parse import unquote, urlparse


# ============================================================
# Configuración general
# ============================================================

SEPARADOR_SALIDA = " | "
NOMBRE_TXT_DEFECTO = "indice-tesauro-estandar.txt"
NOMBRE_XML_DEFECTO = "indice-oai-pmh.xml"
CARPETA_EXCLUIDA_DEFECTO = "img"
CABECERA_TXT = SEPARADOR_SALIDA.join(["URI_objeto", "título", "lista de términos"])

# Espacios de nombres OAI-PMH / Dublin Core
NS_OAI = "http://www.openarchives.org/OAI/2.0/"
NS_OAI_DC = "http://www.openarchives.org/OAI/2.0/oai_dc/"
NS_DC = "http://purl.org/dc/elements/1.1/"
NS_XSI = "http://www.w3.org/2001/XMLSchema-instance"

SCHEMA_OAI = "http://www.openarchives.org/OAI/2.0/ http://www.openarchives.org/OAI/2.0/OAI-PMH.xsd"
SCHEMA_OAI_DC = "http://www.openarchives.org/OAI/2.0/oai_dc/ http://www.openarchives.org/OAI/2.0/oai_dc.xsd"

ET.register_namespace("", NS_OAI)
ET.register_namespace("oai_dc", NS_OAI_DC)
ET.register_namespace("dc", NS_DC)
ET.register_namespace("xsi", NS_XSI)


# ============================================================
# Modelos de datos
# ============================================================

@dataclass
class RegistroTesauro:
    uri: str
    titulo: str
    terminos: list[str]
    numero: int


@dataclass
class Estadisticas:
    filas_leidas: int = 0
    urls_leidas: int = 0
    ficheros_escritos: int = 0
    carpetas_descartadas: int = 0
    carpeta_excluida_descartadas: int = 0
    raiz_descartadas: int = 0
    filas_ignoradas: int = 0
    raiz_no_encontrada: int = 0
    registros: list[RegistroTesauro] = field(default_factory=list)


# ============================================================
# Utilidades básicas
# ============================================================

def qname(namespace: str, etiqueta: str) -> str:
    return f"{{{namespace}}}{etiqueta}"


def leer_texto_robusto(ruta: Path) -> tuple[str, str]:
    """Lee el CSV aunque venga con BOM UTF-8 o codificación Windows/Latin."""
    datos = ruta.read_bytes()

    if datos.startswith(codecs.BOM_UTF8):
        datos = datos[len(codecs.BOM_UTF8):]

    for codificacion in ("utf-8", "cp1252", "latin-1"):
        try:
            return datos.decode(codificacion), codificacion
        except UnicodeDecodeError:
            continue

    return datos.decode("utf-8", errors="replace"), "utf-8 con reemplazos"


def crear_lector_csv(texto: str) -> csv.reader:
    muestra = texto[:4096]

    try:
        dialecto = csv.Sniffer().sniff(muestra, delimiters=",;\t|")
    except csv.Error:
        dialecto = csv.excel

    return csv.reader(StringIO(texto), dialecto)


def limpiar_celda(valor: str) -> str:
    valor = valor.strip()

    if len(valor) >= 2 and valor[0] == valor[-1] and valor[0] in {"'", '"'}:
        valor = valor[1:-1]

    return valor.strip()


def obtener_url_desde_fila(fila: list[str]) -> str | None:
    """Devuelve la primera celda que parezca una URL."""
    for celda in fila:
        valor = limpiar_celda(celda)
        if "://" in valor:
            return valor
    return None


def segmentos_uri(uri: str) -> list[str]:
    ruta = unquote(urlparse(uri).path).strip("/")
    if not ruta:
        return []
    return [segmento for segmento in ruta.split("/") if segmento]


def titulo_desde_segmentos(segmentos: list[str]) -> str:
    return segmentos[-1] if segmentos else ""


def es_fichero_por_titulo(titulo: str) -> bool:
    return bool(PurePosixPath(titulo).suffix)


def contiene_carpeta_excluida(segmentos: list[str], carpeta_excluida: str) -> bool:
    carpeta_excluida = carpeta_excluida.casefold()
    carpetas = segmentos[:-1]
    return any(carpeta.casefold() == carpeta_excluida for carpeta in carpetas)


def esta_en_subcarpeta_de_la_raiz(
    segmentos: list[str],
    carpeta_raiz: str,
) -> tuple[bool, bool]:
    """
    Comprueba si el fichero está dentro de una subcarpeta de la carpeta raíz.

    Ejemplo aceptado:
        /ebiblio_melilla_riff/subcarpeta/fichero.pdf

    Ejemplo descartado:
        /ebiblio_melilla_riff/fichero.pdf

    Si la carpeta raíz no aparece en la URL, se acepta el registro y se deja aviso
    en estadísticas, porque no puede verificarse contra la carpeta local activa.
    """
    if not segmentos:
        return False, False

    raiz_normalizada = carpeta_raiz.casefold()
    carpetas = segmentos[:-1]

    posiciones = [
        i for i, carpeta in enumerate(carpetas)
        if carpeta.casefold() == raiz_normalizada
    ]

    if not posiciones:
        return True, False

    indice_raiz = posiciones[-1]
    carpetas_despues_de_raiz = carpetas[indice_raiz + 1:]

    return len(carpetas_despues_de_raiz) >= 1, True


def unicos_preservando_orden(valores: list[str]) -> list[str]:
    vistos: set[str] = set()
    resultado: list[str] = []

    for valor in valores:
        clave = valor.casefold()
        if clave not in vistos:
            vistos.add(clave)
            resultado.append(valor)

    return resultado


def extraer_terminos(titulo: str) -> list[str]:
    base = PurePosixPath(titulo).stem
    terminos = [termino.strip() for termino in re.split(r"[-_]+", base) if termino.strip()]
    return unicos_preservando_orden(terminos)


def escapar_campo_txt(valor: str) -> str:
    return (
        valor
        .replace(" | ", " / ")
        .replace("\r", " ")
        .replace("\n", " ")
        .strip()
    )


def tipo_dc_desde_extension(titulo: str) -> str:
    extension = PurePosixPath(titulo).suffix.casefold()

    imagenes = {".jpg", ".jpeg", ".png", ".gif", ".tif", ".tiff", ".bmp", ".webp"}
    audio = {".mp3", ".wav", ".flac", ".ogg", ".m4a", ".aac"}
    video = {".mp4", ".mov", ".avi", ".mkv", ".wmv", ".webm"}
    texto = {".txt", ".pdf", ".doc", ".docx", ".rtf", ".odt", ".html", ".htm", ".xml"}

    if extension in imagenes:
        return "Image"
    if extension in audio:
        return "Sound"
    if extension in video:
        return "MovingImage"
    if extension in texto:
        return "Text"

    return "Dataset"


def formato_mime_desde_titulo(titulo: str) -> str | None:
    tipo, _ = mimetypes.guess_type(titulo)
    return tipo


# ============================================================
# Generación del índice TXT
# ============================================================

def generar_indice_tesauro(
    entrada: Path,
    salida_txt: Path,
    carpeta_raiz: str,
    carpeta_excluida: str,
    incluir_cabecera: bool = True,
) -> tuple[Estadisticas, str]:

    texto, codificacion = leer_texto_robusto(entrada)
    lector = crear_lector_csv(texto)
    estadisticas = Estadisticas()

    with salida_txt.open("w", encoding="utf-8", newline="") as fichero_salida:
        if incluir_cabecera:
            fichero_salida.write(CABECERA_TXT + "\n")

        for fila in lector:
            estadisticas.filas_leidas += 1

            uri = obtener_url_desde_fila(fila)
            if not uri:
                estadisticas.filas_ignoradas += 1
                continue

            estadisticas.urls_leidas += 1

            segmentos = segmentos_uri(uri)
            titulo = titulo_desde_segmentos(segmentos)

            if not titulo or not es_fichero_por_titulo(titulo):
                estadisticas.carpetas_descartadas += 1
                continue

            if contiene_carpeta_excluida(segmentos, carpeta_excluida):
                estadisticas.carpeta_excluida_descartadas += 1
                continue

            en_subcarpeta, raiz_encontrada = esta_en_subcarpeta_de_la_raiz(
                segmentos=segmentos,
                carpeta_raiz=carpeta_raiz,
            )

            if not raiz_encontrada:
                estadisticas.raiz_no_encontrada += 1

            if not en_subcarpeta:
                estadisticas.raiz_descartadas += 1
                continue

            terminos = extraer_terminos(titulo)

            linea = SEPARADOR_SALIDA.join([
                escapar_campo_txt(uri),
                escapar_campo_txt(titulo),
                escapar_campo_txt(", ".join(terminos)),
            ])

            fichero_salida.write(linea + "\n")

            estadisticas.ficheros_escritos += 1
            estadisticas.registros.append(
                RegistroTesauro(
                    uri=uri,
                    titulo=titulo,
                    terminos=terminos,
                    numero=estadisticas.ficheros_escritos,
                )
            )

    return estadisticas, codificacion


# ============================================================
# Generación XML OAI-PMH / oai_dc
# ============================================================

def añadir_dc_si_valor(dc: ET.Element, etiqueta: str, valor: str | None) -> None:
    if valor is None:
        return

    valor = str(valor).strip()
    if not valor:
        return

    elemento = ET.SubElement(dc, qname(NS_DC, etiqueta))
    elemento.text = valor


def construir_record_oai(
    registro: RegistroTesauro,
    datestamp: str,
    id_prefix: str,
    id_width: int,
    set_spec: str | None,
    publisher: str | None,
    source: str | None,
    rights: str | None,
    language: str | None,
) -> ET.Element:

    record = ET.Element(qname(NS_OAI, "record"))

    header = ET.SubElement(record, qname(NS_OAI, "header"))
    identificador_oai = f"{id_prefix}{str(registro.numero).zfill(id_width)}"

    ET.SubElement(header, qname(NS_OAI, "identifier")).text = identificador_oai
    ET.SubElement(header, qname(NS_OAI, "datestamp")).text = datestamp

    if set_spec:
        ET.SubElement(header, qname(NS_OAI, "setSpec")).text = set_spec

    metadata = ET.SubElement(record, qname(NS_OAI, "metadata"))

    dc = ET.SubElement(
        metadata,
        qname(NS_OAI_DC, "dc"),
        {
            qname(NS_XSI, "schemaLocation"): SCHEMA_OAI_DC,
        },
    )

    # Campos Dublin Core mínimos y útiles para recolección básica.
    añadir_dc_si_valor(dc, "identifier", registro.uri)
    añadir_dc_si_valor(dc, "title", registro.titulo)

    for termino in registro.terminos:
        añadir_dc_si_valor(dc, "subject", termino)

    añadir_dc_si_valor(dc, "type", tipo_dc_desde_extension(registro.titulo))
    añadir_dc_si_valor(dc, "format", formato_mime_desde_titulo(registro.titulo))
    añadir_dc_si_valor(dc, "publisher", publisher)
    añadir_dc_si_valor(dc, "source", source)
    añadir_dc_si_valor(dc, "language", language)
    añadir_dc_si_valor(dc, "rights", rights)

    return record


def generar_xml_oai_pmh(
    registros: list[RegistroTesauro],
    salida_xml: Path,
    datestamp: str,
    base_url_oai: str,
    id_prefix: str,
    id_width: int,
    set_spec: str | None,
    publisher: str | None,
    source: str | None,
    rights: str | None,
    language: str | None,
) -> None:

    root = ET.Element(
        qname(NS_OAI, "OAI-PMH"),
        {
            qname(NS_XSI, "schemaLocation"): SCHEMA_OAI,
        },
    )

    ET.SubElement(root, qname(NS_OAI, "responseDate")).text = (
        datetime.now(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")
    )

    request = ET.SubElement(
        root,
        qname(NS_OAI, "request"),
        {
            "verb": "ListRecords",
            "metadataPrefix": "oai_dc",
        },
    )
    request.text = base_url_oai

    list_records = ET.SubElement(root, qname(NS_OAI, "ListRecords"))

    for registro in registros:
        record = construir_record_oai(
            registro=registro,
            datestamp=datestamp,
            id_prefix=id_prefix,
            id_width=id_width,
            set_spec=set_spec,
            publisher=publisher,
            source=source,
            rights=rights,
            language=language,
        )
        list_records.append(record)

    arbol = ET.ElementTree(root)
    ET.indent(arbol, space="  ", level=0)
    arbol.write(salida_xml, encoding="utf-8", xml_declaration=True)


# ============================================================
# Consola
# ============================================================

def linea(clave: str, valor: object) -> str:
    return f"  {clave:<42} {valor}"


def imprimir_resumen(
    entrada: Path,
    salida_txt: Path,
    salida_xml: Path,
    carpeta_raiz: str,
    carpeta_excluida: str,
    estadisticas: Estadisticas,
    codificacion: str,
    datestamp: str,
    base_url_oai: str,
    id_prefix: str,
) -> None:

    ancho = 78
    borde = "═" * ancho

    print()
    print(borde)
    print("  GTE-OAI · GENERADOR DE TESAURO + OAI-PMH  ".center(ancho))
    print(borde)
    print(linea("Entrada", entrada))
    print(linea("Índice TXT", salida_txt))
    print(linea("XML OAI-PMH", salida_xml))
    print(linea("Codificación leída", codificacion))
    print(linea("Carpeta raíz tomada como activa", carpeta_raiz))
    print(linea("Carpeta omitida", carpeta_excluida))
    print(linea("Datestamp OAI-PMH", datestamp))
    print(linea("Base URL OAI-PMH", base_url_oai))
    print(linea("Prefijo identifier OAI", id_prefix))
    print("─" * ancho)
    print(linea("Filas leídas", estadisticas.filas_leidas))
    print(linea("URLs detectadas", estadisticas.urls_leidas))
    print(linea("Registros OAI-PMH generados", estadisticas.ficheros_escritos))
    print(linea("Carpetas descartadas", estadisticas.carpetas_descartadas))
    print(linea("Ficheros en carpeta activa omitidos", estadisticas.raiz_descartadas))
    print(linea(f"Ficheros dentro de '{carpeta_excluida}' omitidos", estadisticas.carpeta_excluida_descartadas))
    print(linea("Filas ignoradas", estadisticas.filas_ignoradas))

    if estadisticas.raiz_no_encontrada:
        print("─" * ancho)
        print("  AVISO")
        print("  En algunas URLs no apareció la carpeta raíz indicada.")
        print("  Se aceptaron, pero no pudieron verificarse contra la carpeta activa local.")
        print(linea("URLs sin carpeta raíz localizada", estadisticas.raiz_no_encontrada))

    print(borde)
    print("  Proceso completado: índice y XML listos para revisión.  ".center(ancho))
    print(borde)
    print()


# ============================================================
# Programa principal
# ============================================================

def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Genera indice-tesauro-estandar.txt y un XML OAI-PMH/oai_dc "
            "a partir de un CSV/listado de URLs."
        )
    )

    parser.add_argument(
        "entrada",
        nargs="?",
        default="indice-tesauro.csv",
        help="Fichero CSV de entrada. Por defecto: indice-tesauro.csv",
    )

    parser.add_argument(
        "-t",
        "--txt",
        default=NOMBRE_TXT_DEFECTO,
        help=f"Fichero TXT de salida. Por defecto: {NOMBRE_TXT_DEFECTO}",
    )

    parser.add_argument(
        "-x",
        "--xml",
        default=NOMBRE_XML_DEFECTO,
        help=f"Fichero XML OAI-PMH de salida. Por defecto: {NOMBRE_XML_DEFECTO}",
    )

    parser.add_argument(
        "--carpeta-raiz",
        default=Path.cwd().name,
        help=(
            "Nombre de la carpeta activa dentro de la URL. "
            "Por defecto se usa el nombre de la carpeta desde la que se ejecuta el guion."
        ),
    )

    parser.add_argument(
        "--carpeta-excluida",
        default=CARPETA_EXCLUIDA_DEFECTO,
        help=f"Carpeta que se omitirá por completo. Por defecto: {CARPETA_EXCLUIDA_DEFECTO}",
    )

    parser.add_argument(
        "--datestamp",
        default=date.today().isoformat(),
        help="Fecha OAI-PMH de los registros en formato AAAA-MM-DD. Por defecto: fecha actual.",
    )

    parser.add_argument(
        "--base-url-oai",
        default="https://marafd.org/oai",
        help="URL base del repositorio OAI-PMH. Por defecto: https://marafd.org/oai",
    )

    parser.add_argument(
        "--id-prefix",
        default="oai:marafd.org:",
        help="Prefijo de los identificadores OAI. Por defecto: oai:marafd.org:",
    )

    parser.add_argument(
        "--id-width",
        type=int,
        default=6,
        help="Anchura numérica con ceros a la izquierda. Por defecto: 6.",
    )

    parser.add_argument(
        "--set-spec",
        default="marafd",
        help="Valor opcional de setSpec. Por defecto: marafd. Usa cadena vacía para omitirlo.",
    )

    parser.add_argument(
        "--publisher",
        default="MARAFd",
        help="Valor dc:publisher. Por defecto: MARAFd. Usa cadena vacía para omitirlo.",
    )

    parser.add_argument(
        "--source",
        default="MARAFd",
        help="Valor dc:source. Por defecto: MARAFd. Usa cadena vacía para omitirlo.",
    )

    parser.add_argument(
        "--language",
        default="",
        help="Valor dc:language, por ejemplo es, fr, ar. Por defecto se omite.",
    )

    parser.add_argument(
        "--rights",
        default="",
        help="Valor dc:rights/licencia. Por defecto se omite.",
    )

    parser.add_argument(
        "--sin-cabecera-txt",
        action="store_true",
        help="No escribe la línea de cabecera en el TXT.",
    )

    args = parser.parse_args()

    entrada = Path(args.entrada)
    salida_txt = Path(args.txt)
    salida_xml = Path(args.xml)

    if not entrada.exists():
        print(f"ERROR: no existe el fichero de entrada: {entrada}", file=sys.stderr)
        raise SystemExit(1)

    if args.id_width < 1:
        print("ERROR: --id-width debe ser igual o mayor que 1", file=sys.stderr)
        raise SystemExit(1)

    estadisticas, codificacion = generar_indice_tesauro(
        entrada=entrada,
        salida_txt=salida_txt,
        carpeta_raiz=args.carpeta_raiz,
        carpeta_excluida=args.carpeta_excluida,
        incluir_cabecera=not args.sin_cabecera_txt,
    )

    generar_xml_oai_pmh(
        registros=estadisticas.registros,
        salida_xml=salida_xml,
        datestamp=args.datestamp,
        base_url_oai=args.base_url_oai,
        id_prefix=args.id_prefix,
        id_width=args.id_width,
        set_spec=args.set_spec or None,
        publisher=args.publisher or None,
        source=args.source or None,
        rights=args.rights or None,
        language=args.language or None,
    )

    imprimir_resumen(
        entrada=entrada,
        salida_txt=salida_txt,
        salida_xml=salida_xml,
        carpeta_raiz=args.carpeta_raiz,
        carpeta_excluida=args.carpeta_excluida,
        estadisticas=estadisticas,
        codificacion=codificacion,
        datestamp=args.datestamp,
        base_url_oai=args.base_url_oai,
        id_prefix=args.id_prefix,
    )


if __name__ == "__main__":
    main()
