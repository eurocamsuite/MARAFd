from __future__ import annotations

from pathlib import Path
import re

OUTPUT_FILE = "jointall_output.txt"
REPORT_FILE = "jointall_report.txt"

# Líneas frecuentes de ruido OCR/escaneo que conviene eliminar.
# Se eliminan solo si aparecen como línea completa.
NOISE_LINE_PATTERNS = [
    re.compile(r"^\s*THE UNIVERSITY OF MICHIGAN\s*$", re.IGNORECASE),
    re.compile(r"^\s*Digitized by Google\s*$", re.IGNORECASE),
    re.compile(r"^\s*Original from\s+THE UNIVERSITY OF MICHIGAN\s*$", re.IGNORECASE),
    re.compile(r"^\s*Original from\s+UNIVERSITY OF MICHIGAN\s*$", re.IGNORECASE),
    re.compile(r"^\s*Google\s*$", re.IGNORECASE),
]

# Acepta dos formatos de nombre:
#   1) 00000001.txt
#   2) UCAL_B2801337_00000001.txt
# En ambos casos se usa el bloque numérico final para ordenar.
TRAILING_NUMBER_RE = re.compile(r"^(?P<prefix>.*?)(?P<sep>[_-]?)(?P<number>\d+)$")


def extract_order_info(path: Path) -> tuple[str, int] | None:
    if not path.is_file() or path.suffix.lower() != ".txt":
        return None

    stem = path.stem

    if stem.isdigit():
        return "", int(stem)

    match = TRAILING_NUMBER_RE.match(stem)
    if not match:
        return None

    prefix = match.group("prefix")
    number = match.group("number")

    # Evita aceptar nombres cuyo bloque numérico sea en realidad todo el nombre,
    # porque ese caso ya lo cubre stem.isdigit().
    if not prefix:
        return None

    return prefix.lower(), int(number)


def is_mergeable_txt(path: Path) -> bool:
    return extract_order_info(path) is not None


def sort_key(path: Path) -> tuple[str, int, str]:
    info = extract_order_info(path)
    if info is None:
        return "~", float("inf"), path.name.lower()

    prefix, number = info
    return prefix, number, path.name.lower()


def is_noise_line(line: str) -> bool:
    stripped = line.strip()
    if not stripped:
        return False
    return any(pattern.match(stripped) for pattern in NOISE_LINE_PATTERNS)


def clean_text(text: str) -> tuple[str, int]:
    # Normaliza saltos de línea
    text = text.replace("\r\n", "\n").replace("\r", "\n")

    removed_noise_lines = 0
    cleaned_lines: list[str] = []

    for line in text.split("\n"):
        # Quita espacios al final, preservando el contenido
        line = line.rstrip()

        if is_noise_line(line):
            removed_noise_lines += 1
            continue

        # Reduce espacios/tabs múltiples internos
        line = re.sub(r"[ \t]+", " ", line)
        cleaned_lines.append(line)

    text = "\n".join(cleaned_lines)

    # Colapsa exceso de líneas en blanco
    text = re.sub(r"\n{3,}", "\n\n", text)

    # Limpieza final
    text = text.strip()

    return text, removed_noise_lines


def main() -> None:
    folder = Path(__file__).resolve().parent

    files = sorted(
        (p for p in folder.iterdir() if is_mergeable_txt(p)),
        key=sort_key,
    )

    if not files:
        print(
            "No se encontraron archivos .txt compatibles en la carpeta "
            "(numéricos o con sufijo numérico final)."
        )
        return

    output_path = folder / OUTPUT_FILE
    report_path = folder / REPORT_FILE

    total_files = len(files)
    empty_files = 0
    written_files = 0
    total_noise_lines_removed = 0

    report_lines = []
    report_lines.append("INFORME DE CONCATENACIÓN")
    report_lines.append("=" * 30)
    report_lines.append(f"Carpeta: {folder}")
    report_lines.append(
        "Ficheros .txt compatibles detectados: "
        f"{total_files} (numéricos o con sufijo numérico final)"
    )
    report_lines.append("")

    with output_path.open("w", encoding="utf-8", newline="\n") as fout:
        first_written = True

        for file_path in files:
            try:
                raw_text = file_path.read_text(encoding="utf-8", errors="replace")
            except Exception as exc:
                report_lines.append(f"[ERROR] {file_path.name}: {exc}")
                continue

            original_nonempty = bool(raw_text.strip())
            cleaned_text, removed_noise = clean_text(raw_text)

            total_noise_lines_removed += removed_noise

            if not cleaned_text:
                empty_files += 1
                status = "vacío o sin contenido útil tras limpieza"
                report_lines.append(
                    f"{file_path.name} -> {status} | líneas_ruido_eliminadas={removed_noise}"
                )
                continue

            if not first_written:
                fout.write("\n\n")
            fout.write(cleaned_text)
            first_written = False
            written_files += 1

            report_lines.append(
                f"{file_path.name} -> OK | "
                f"contenido_original={'sí' if original_nonempty else 'no'} | "
                f"líneas_ruido_eliminadas={removed_noise}"
            )

    report_lines.append("")
    report_lines.append("RESUMEN")
    report_lines.append("-" * 30)
    report_lines.append(f"Ficheros detectados: {total_files}")
    report_lines.append(f"Ficheros escritos en salida: {written_files}")
    report_lines.append(f"Ficheros vacíos/sin contenido útil: {empty_files}")
    report_lines.append(f"Líneas de ruido eliminadas: {total_noise_lines_removed}")
    report_lines.append(f"Salida generada: {OUTPUT_FILE}")

    report_path.write_text("\n".join(report_lines) + "\n", encoding="utf-8")

    print(f"Concatenación completada: {output_path.name}")
    print(f"Informe generado: {report_path.name}")
    print(f"Ficheros detectados: {total_files}")
    print(f"Ficheros escritos: {written_files}")
    print(f"Ficheros vacíos/sin contenido útil: {empty_files}")
    print(f"Líneas de ruido eliminadas: {total_noise_lines_removed}")


if __name__ == "__main__":
    main()
