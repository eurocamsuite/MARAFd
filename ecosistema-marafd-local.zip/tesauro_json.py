# ToolKit tesauro_json.py by MARAFd - TECNOLOGIA PARA LA GESTION DE FONDOS DOCUMENTALES DIGITALES
# https://calentamientoglobalacelerado.net/MARAFd/
# PROYECTO: MARAFd - GESTION INTELIGENTE DE FONDOS DOCUMENTALES DIGITALES BASADA EN TESAURO                     
# OPEN SOURCE SOLUTION by RAFAEL LOMENA VARO - MARAF SOFT 1993 ©© 2025    
# Autor: Original por ChatGPT, modificado por Claude
# Idea original: Rafael Lomena - MaRaF SOFT
# Ecosistema tecnologia: MARAFd (c)(c) 2025

# En Windows instala Python antes de ejecutar esta herramienta
#
# Desde Windows CMD..
#
# descarga:
#       curl -o python-3.12.2-amd64.exe https://www.python.org/ftp/python/3.12.2/python-3.12.2-amd64.exe

# instalar:
#       python-3.12.2-amd64.exe InstallAllUsers=1 PrependPath=1 Include_test=0
#
# .. y la libreria windows-curses desde consola:
#       pip install windows-curses
#
# Verifica instalacion:
#       python --version
#       pip --version

import json
from pathlib import Path

# === CONFIGURACIÓN ===
#     ESCOGE EL FICHERO INDICE-TESAURO QUE DESEAS CONVERTIR A JSON Y EL FICHERO DE SALIDA:

archivo_entrada = "indice-tesauro_compacto2.txt"  # fichero con índice
repositorio_base = "https://calentamientoglobalacelerado.net/ebiblio_melilla_riff/"
archivo_salida = "indice-tesauro_compacto2.json"

# === FUNCIONES ===

def tiene_extension(nombre):
    base = Path(nombre).name
    return '.' in base

def construir_json(archivo_txt, base_url):
    with open(archivo_txt, "r", encoding="utf-8", errors="ignore") as f:
        lineas = [line.strip() for line in f if line.strip()]

    datos = []
    for linea in lineas:
        tipo = "archivo" if tiene_extension(linea) else "carpeta"
        url = base_url + linea
        datos.append({
            "tipo": tipo,
            "nombre": linea,
            "url": url
        })

    estructura = {
        "repositorio": base_url,
        "fecha": "2025-04-16",
        "indice": datos
    }

    return estructura

# === EJECUCIÓN ===

if __name__ == "__main__":
    resultado = construir_json(archivo_entrada, repositorio_base)
    with open(archivo_salida, "w", encoding="utf-8") as f:
        json.dump(resultado, f, indent=2, ensure_ascii=False)

    print(f"Archivo JSON generado: {archivo_salida}")
