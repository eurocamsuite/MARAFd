' PROYECTO: MARAFd - GESTION INTELIGENTE DE FONDOS DOCUMENTALES DIGITALES BASADA EN TESAURO                     
' Ecosistema tecnologia: MARAFd (c)(c) 2025
' ToolKit: TIA.bas by MARAFd - TECNOLOGIA PARA LA GESTION DE FONDOS DOCUMENTALES DIGITALES
' Creative Commons Attribution-NonCommercial-ShareAlike 4.0 - 06/02/2025 - Num.reg. 2502060809787          
' OPEN SOURCE SOLUTION by RAFAEL LOMENA VARO - MARAF SOFT 1993 ©© 2025    
' Idea original: Rafael Lomena - MaRaF SOFT
' Autor código: Original por ChatGPT, modificado por Claude y autor                               
' https://calentamientoglobalacelerado.net/MARAFd/
'                
' Program: TIA [ TESAURO INTELIGENCIA ARTIFICIAL ]                                             
' Version: 1.1 for WINDOWS x64                                                                 
' Fecha: 02/03/2025      
' Autor: Original por ChatGPT, modificado por Claude y autor idea 
' Idea original: Rafael Lomena Varo - MaRaF SOFT                                                        
' Ecosistema tecnologia: MARAFd (c)(c) 2025                                 
'
' Descripcion: VALIDACION, ADAPTACION DE ENLACES Y GENERACION DE ARCHIVO PARA PROCESAMIENTO POR IA
'
' Compilador: FreeBASIC (v1.08.1) GCC-9.3.0
' Compilado-linkado: fbc64 TIA.bas -s console (resultante TIA.exe)
'
' FLUJO DEL PROCESO:
'    se lee volcado del fondo completo "index_fondo_Melilla_Rif.asc"
'    Se validan cadenas y se genera reporte de warnings en "TIA_tesauro_report.txt"
'    Se genera "indice-tesauro.txt"
'    Se genera "indice-tesauro.csv"

 
Dim As String inputFile = "index_fondo_Melilla_Rif.asc", _
              outputFile = "indice-tesauro.txt", _
              csvFile = "indice-tesauro.csv", _
              reportFile = "TIA_tesauro_report.txt"

Dim As String txt, baseUrl = "https://calentamientoglobalacelerado.net/ebiblio_melilla_riff/"
Dim As Integer skip = 1
Dim As Integer contador_lineas = 0, contador_warnings = 0
Dim As String warningsReport = ""
 
' Función para reemplazar "\\" y "\" por "/"
Function ReplaceBackslash(ByRef s As String) As String
    Dim As String result = ""
    Dim As Integer i = 1
    Do While i <= Len(s)
        Dim As String c = Mid(s, i, 1)
        If c = "\" Then
            result &= "/"
            ' Si hay una segunda barra invertida consecutiva, saltarla
            If i < Len(s) Then
                If Mid(s, i + 1, 1) = "\" Then
                    i += 1
                End If
            End If
        Else
            result &= c
        End If
        i += 1
    Loop
    Return result
End Function
 
' Abrir el archivo de entrada y los archivos de salida
Open inputFile For Input As #1
Open outputFile For Output As #2
Open csvFile For Output As #4
 
' Escribir BOM de UTF-8 en los archivos de índice (sin salto de línea)
Print #2, Chr(&HEF) + Chr(&HBB) + Chr(&HBF);
Print #4, Chr(&HEF) + Chr(&HBB) + Chr(&HBF);
 
' Escribir cabecera del archivo CSV
Print #4, "URL-archivo-online"
 
While Not Eof(1)
    Line Input #1, txt
    contador_lineas += 1
    If skip > 0 Then
        skip -= 1
    Else
        txt = ReplaceBackslash(txt)
        If Left(txt, 4) <> "http" Then txt = baseUrl & txt
        Print #2, txt
        Print #4, "'" & txt & "'"   ' Escribe la URL entre comillas simples en el CSV
 
        If (InStr(txt, " ") > 0) Or _
           (InStr(txt, "Ã¡") > 0) Or (InStr(txt, "Ã©") > 0) Or (InStr(txt, "Ã­") > 0) Or (InStr(txt, "Ã³") > 0) Or (InStr(txt, "Ãº") > 0) Or _
           (InStr(txt, "Ã") > 0) Or (InStr(txt, "Ã") > 0) Or (InStr(txt, "Ã") > 0) Or (InStr(txt, "Ã") > 0) Or (InStr(txt, "Ã") > 0) Or _
           (InStr(txt, "Ã±") > 0) Or (InStr(txt, "Ã") > 0) Or _
           (InStr(txt, "%") > 0) Then
            warningsReport &= txt & Chr(10)
            contador_warnings += 1
        End If
    End If
Wend
 
Close #1
Close #2
Close #4
 
' Generar el informe
Open reportFile For Output As #3
Print #3, " ************* Reporte software TIA - Tecnologia MARAFd **************"
Print #3, "                    Reporte del tesauro generado: " & Date$() & " " & Time$()
Print #3, "   NUM. registros/lineas procesadas en el Indice: " & contador_lineas
Print #3, " Total de warnings detectados en Indice-tesauro : " & contador_warnings
Print #3, " LINEAS A  REVISAR MANUALMENTE EN INDICE-TESAURO:"
Print #3, " * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *"
Print #3, ""
Print #3, warningsReport
Close #3
