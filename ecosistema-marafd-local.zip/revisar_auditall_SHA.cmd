@echo off
echo SCRIPT PARA AUDITORIA MASIVA DE CONGRUENCIA DEL FONDO DOCUMENTAL DIGITAL
echo  - (recomendado comprobar antes local_SHA_report.txt y web_SHA_report.txt)
echo COMPARATIVA DE IDENTIFICADORES SHA A TRAVES DE LAS FUENTES SIGUIENTES:
echo  - Fuente  local: local_SHA.json
echo  - Fuente server: web_SHA.json
echo  -
echo Lanzando Proceso en paralelo local-server:
echo  - Inicio proceso en local ...
local_SHA.exe
echo  - Inicio proceso en server ...
start https://calentamientoglobalacelerado.net/ebiblio_melilla_riff/web_SHA.php?reset=1
echo  -
echo Finalizados ambos procesos se ejecuta rutina comparativa de SHA en local:
compare_SHA.exe
echo  -
echo Generado compare_SHA_report.txt para ver diferencias.
edit compare_SHA_report.txt 