@echo off
@cls
echo $ Contando registros y calculando espacio del fondo documental..
set "TARGET_DIR=D:\_fondos\ebiblio_melilla_riff\"
set "OUTPUT_FILE=numregs.dat"

if not exist "%TARGET_DIR%" (
    echo La carpeta especificada no existe: %TARGET_DIR%
    exit /b 1
)

:: Contar archivos
for /f %%A in ('dir /s /a-d /b "%TARGET_DIR%" ^| find /c /v ""') do set "FILE_COUNT=%%A"

:: Calcular tamanyo total en GB con PowerShell
for /f "delims=" %%A in ('powershell -command "$size = (Get-ChildItem -Path '%TARGET_DIR%' -Recurse | Measure-Object -Property Length -Sum).Sum / 1GB; [math]::Round($size, 2)"') do set "SIZE_GB=%%A"

:: Escribir resultados en el archivo
echo %FILE_COUNT% > "%OUTPUT_FILE%"
echo %SIZE_GB% >> "%OUTPUT_FILE%"
echo $ Datos guardados en fichero numregs.dat
timeout /t 2
@chcp 1252

echo   '
echo   $ Please wait...
echo    [ Indexando repositorio ... ]
dir /b /s /o:n >> index_fondo_Melilla_Rif.tmp
echo   $ Proceso de indexado OK ...
echo   $ Adaptando INDICE para enlaces URLs en servidor ...
timeout /t 4 /nobreak >nul
setlocal enabledelayedexpansion

echo INDICE-TESAURO > index_fondo_Melilla_Rif.asc

>>index_fondo_Melilla_Rif.asc (
    for /f "delims=" %%i in (index_fondo_Melilla_Rif.tmp) do (
        set "line=%%i"
        echo !line:D:\_fondos\ebiblio_melilla_riff\=!
    )
)

timeout /t 2 /nobreak >nul
echo   $ Iniciando procesos de normalizaciOn y refresco..
echo   $ [ TIA.exe ] Revisando INDICE-TESAURO y generando versiones TXT y CSV.. [y reporte WARNINGs TIA_tesauro_report.txt]
TIA.exe
timeout /t 2 /nobreak >nul
echo   $ Eliminando archivo de INDEX temporal..
del index_fondo_Melilla_Rif.tmp

echo   $ [ compacTIA.exe ] Compactando INDICE-TESAURO y generando archivos compactos Tesauro y Tesauro-2 ...
compacTIA.exe
echo   $ [ gte-OAI.py ] Generando INDICE-TESAURO-ESTANDAR.txt y reestructurando repositorio bajo estandar OAI-PMH en inidice-oai-pmh.xml ...
python gte-OAI.py indice-tesauro.csv
timeout /t 3 /nobreak >nul
echo   $ [ WinSCP.exe ] Conectando al servidor mediante SFTP..
timeout /t 2 /nobreak >nul
echo   $      Subiendo archivos actualizados a directorio /fondo_documental_Melilla_Riff
timeout /t 2 /nobreak >nul
echo   $      Subiendo archivos actualizados a directorio /ebiblio_melilla_riff
timeout /t 2 /nobreak >nul
echo   $      Subiendo archivo indice-oai-pmh.xml actualizado a directorio /oai
"C:\Program Files (x86)\WinSCP\WinSCP.exe" /script=upload_script.txt

if %ERRORLEVEL% neq 0 (
    echo $ Error: No se pudo subir el/los archivo/s al servidor.
) else (
    echo $ Archivo/s subido/s correctamente.
)

echo   $ FIN DE IMPRESION.
pause