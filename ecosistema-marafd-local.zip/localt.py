# PROYECTO: MARAFd - GESTION INTELIGENTE DE FONDOS DOCUMENTALES DIGITALES BASADA EN TESAURO     
# Ecosistema tecnologia: MARAFd (c)(c) 2025
# ToolKit: localT.py by MARAFd - TECNOLOGIA PARA LA GESTION DE FONDOS DOCUMENTALES DIGITALES
# PROYECTO: MARAFd - GESTION INTELIGENTE DE FONDOS DOCUMENTALES DIGITALES BASADA EN TESAURO                     
# OPEN SOURCE SOLUTION by RAFAEL LOMENA VARO - MARAF SOFT 1993 ©© 2025    
# Idea original: Rafael Lomena - MaRaF SOFT
# Autor código: Original por ChatGPT, modificado por Claude y autor                               
# https://calentamientoglobalacelerado.net/MARAFd/

# En Windows instala Python antes de ejecutar esta herramienta
#
# Desde Windows CMD..
#
# descarga:
#       curl -o python-3.12.2-amd64.exe https://www.python.org/ftp/python/3.12.2/python-3.12.2-amd64.exe

# instalar:
#       python-3.12.2-amd64.exe InstallAllUsers=1 PrependPath=1 Include_test=0
#
# .. y la libreria windows-curses desde consola:
#       pip install windows-curses
#
# Verifica instalacion:
#       python --version
#       pip --version
import curses
import locale
import os
import subprocess
import sys

FILENAME = 'index_fondo_Melilla_Rif.asc'

def cargar_lineas(nombre_archivo):
    with open(nombre_archivo, 'r', encoding='utf-8', errors='ignore') as f:
        return f.readlines()

def obtener_tamano_archivo_kb(nombre_archivo):
    try:
        tamano_bytes = os.path.getsize(nombre_archivo)
        return tamano_bytes // 1024
    except:
        return 0

def es_archivo_valido(ruta):
    return os.path.isfile(ruta)

def abrir_documento(ruta):
    try:
        if sys.platform.startswith('win'):
            os.startfile(ruta)
        elif sys.platform.startswith('darwin'):
            subprocess.run(['open', ruta])
        else:
            subprocess.run(['xdg-open', ruta])
    except Exception:
        pass

def obtener_cadena_busqueda(stdscr, anchura):
    prompt = "F3 Buscar: "
    curses.echo()
    curses.curs_set(1)
    stdscr.addstr(0, 0, prompt)
    stdscr.clrtoeol()
    stdscr.move(0, len(prompt))
    entrada = stdscr.getstr(0, len(prompt), 20)
    entrada = entrada.decode('utf-8', errors='ignore').strip()
    curses.noecho()
    curses.curs_set(0)
    return entrada

def buscar_siguiente(lineas, start_idx, cadena):
    cadena_lower = cadena.lower()
    for idx in range(start_idx, len(lineas)):
        if cadena_lower in lineas[idx].lower():
            return idx
    return -1

def tiene_extension(nombre):
    base = os.path.basename(nombre.strip())
    return '.' in base

def main(stdscr):
    curses.curs_set(0)
    curses.start_color()
    curses.use_default_colors()

    # Pairs existing
    curses.init_pair(1, curses.COLOR_CYAN, -1)
    curses.init_pair(2, curses.COLOR_BLACK, curses.COLOR_CYAN)
    curses.init_pair(3, curses.COLOR_BLACK, curses.COLOR_WHITE)
    curses.init_pair(4, curses.COLOR_WHITE, curses.COLOR_BLUE)
    curses.init_pair(5, curses.COLOR_BLUE, curses.COLOR_WHITE)
    curses.init_pair(6, curses.COLOR_RED, curses.COLOR_WHITE)
    curses.init_pair(7, curses.COLOR_YELLOW, curses.COLOR_WHITE)

    # Define dark orange for [DIRs] with WHITE background
    try:
        # Normalize 255,165,0 to 0-1000 range for dark orange
        curses.init_color(9, 1000, 647, 0)
        curses.init_pair(9, 9, curses.COLOR_WHITE)  # Dark orange on white background
    except curses.error:
        # Fallback: use standard yellow on white background
        curses.init_pair(9, curses.COLOR_YELLOW, curses.COLOR_WHITE)

    try:
        curses.init_pair(8, curses.COLOR_YELLOW, -1)
    except curses.error:
        curses.init_pair(8, curses.COLOR_YELLOW, curses.COLOR_BLACK)

    colores_listado = [
        (curses.COLOR_GREEN, -1),
        (curses.COLOR_YELLOW, -1),
        (curses.COLOR_CYAN, -1),
        (curses.COLOR_WHITE, -1)
    ]
    color_index = 0

    lineas = cargar_lineas(FILENAME)
    total_lineas = len(lineas)
    tamano_kb = obtener_tamano_archivo_kb(FILENAME)

    indice = 0
    offset = 0

    search_str = ""
    in_repeat_prompt = False

    while True:
        stdscr.erase()
        altura, anchura = stdscr.getmaxyx()
        area_listado = altura - 2
        if area_listado < 1:
            break

        ayuda = " LocalT 1.0 | No Mouse! | [DIRs] | Flechas ↑↓ | Re/Av.Pág | F8 Color | ESC salir | F3 Buscar: "
        muestra_f3 = ayuda + search_str[:20] if search_str else ayuda

        try:
            # Draw header background
            stdscr.attron(curses.color_pair(3))
            stdscr.addstr(0, 0, muestra_f3.ljust(anchura)[:anchura])
            stdscr.attroff(curses.color_pair(3))

            # Highlight [DIRs] in dark orange with white background
            dir_pos = muestra_f3.find("[DIRs]")
            if dir_pos != -1:
                stdscr.attron(curses.color_pair(9))
                stdscr.addstr(0, dir_pos, "[DIRs]")
                stdscr.attroff(curses.color_pair(9))

            # Draw marca total as before
            marca_total = "M A R A F d "
            pos_inicio = anchura - len(marca_total) - 1
            if pos_inicio > len(muestra_f3) + 2:
                stdscr.attron(curses.color_pair(5))
                stdscr.addstr(0, pos_inicio, "M A ")
                stdscr.attroff(curses.color_pair(5))

                stdscr.attron(curses.color_pair(6))
                stdscr.addstr(0, pos_inicio + 4, "R A ")
                stdscr.attroff(curses.color_pair(6))

                stdscr.attron(curses.color_pair(7))
                stdscr.addstr(0, pos_inicio + 8, "F d")
                stdscr.attroff(curses.color_pair(7))
        except curses.error:
            pass

        for i in range(area_listado):
            idx = offset + i
            if idx >= total_lineas:
                break
            linea_original = lineas[idx].replace('\t', '    ').rstrip()
            linea_sanitizada = ''.join(c for c in linea_original if 32 <= ord(c) <= 126)
            linea_str = linea_sanitizada.strip()

            es_carpeta = not tiene_extension(linea_str)
            if es_carpeta:
                texto = f"[{linea_sanitizada}]".ljust(anchura)[:anchura]
            else:
                texto = linea_sanitizada.ljust(anchura)[:anchura]

            try:
                if idx == indice:
                    stdscr.attron(curses.color_pair(2))
                    stdscr.addstr(i + 1, 0, texto)
                    stdscr.attroff(curses.color_pair(2))
                else:
                    if es_carpeta:
                        stdscr.attron(curses.color_pair(8))
                        stdscr.addstr(i + 1, 0, texto)
                        stdscr.attroff(curses.color_pair(8))
                    else:
                        stdscr.attron(curses.color_pair(1))
                        stdscr.addstr(i + 1, 0, texto)
                        stdscr.attroff(curses.color_pair(1))
            except curses.error:
                continue

        estado = f" Línea {indice + 1}/{total_lineas} | Tamano: {tamano_kb} KB | Local-TESAURO: {FILENAME} |  "

        if in_repeat_prompt:
            rep_msg = " Repetir búsqueda (S/N)? "
            largo_rep = len(rep_msg)
            espacio = anchura - largo_rep - 1

            try:
                stdscr.attron(curses.color_pair(4))
                stdscr.addstr(altura - 1, 0, estado[:espacio].ljust(espacio))
                stdscr.attroff(curses.color_pair(4))

                stdscr.attron(curses.color_pair(8))
                stdscr.addstr(altura - 1, espacio + 1, rep_msg)
                stdscr.attroff(curses.color_pair(8))
            except curses.error:
                pass
        else:
            try:
                stdscr.attron(curses.color_pair(4))
                stdscr.addstr(altura - 1, 0, estado.ljust(anchura)[:anchura])
                stdscr.attroff(curses.color_pair(4))
            except curses.error:
                pass

        stdscr.refresh()
        tecla = stdscr.getch()

        if in_repeat_prompt:
            if tecla in (ord('S'), ord('s')):
                indice = 0
                found_idx = buscar_siguiente(lineas, indice, search_str)
                if found_idx != -1:
                    indice = found_idx
                in_repeat_prompt = False
            elif tecla in (ord('N'), ord('n')):
                in_repeat_prompt = False
                search_str = ""
            continue

        if tecla == 27:
            break
        elif tecla == curses.KEY_DOWN and indice < total_lineas - 1:
            indice += 1
        elif tecla == curses.KEY_UP and indice > 0:
            indice -= 1
        elif tecla == curses.KEY_NPAGE:
            indice = min(indice + area_listado, total_lineas - 1)
        elif tecla == curses.KEY_PPAGE:
            indice = max(indice - area_listado, 0)
        elif tecla == curses.KEY_HOME:
            indice = 0
        elif tecla == curses.KEY_END:
            indice = total_lineas - 1
        elif tecla == curses.KEY_F8:
            color_index = (color_index + 1) % len(colores_listado)
            fg, bg = colores_listado[color_index]
            curses.init_pair(1, fg, bg)
        elif tecla == curses.KEY_F3:
            if not search_str:
                nueva_cadena = obtener_cadena_busqueda(stdscr, anchura)
                if nueva_cadena:
                    search_str = nueva_cadena
                    found_idx = buscar_siguiente(lineas, indice, search_str)
                    if found_idx != -1:
                        indice = found_idx
            else:
                found_idx = buscar_siguiente(lineas, indice + 1, search_str)
                if found_idx != -1:
                    indice = found_idx
                else:
                    in_repeat_prompt = True
        elif tecla == 10:
            ruta = lineas[indice].strip()
            if es_archivo_valido(ruta):
                abrir_documento(ruta)

        if indice < offset:
            offset = indice
        elif indice >= offset + area_listado:
            offset = indice - area_listado + 1

if __name__ == '__main__':
    locale.setlocale(locale.LC_ALL, '')
    curses.wrapper(main)