@echo off
echo Proceso de backup/sincronizado ...

robocopy \_fondos\ebiblio_melilla_riff i:\ebiblio_melilla_riff /MIR /NP
robocopy \_fondos\ebiblio_historia_antigua_01 i:\ebiblio_historia_antigua_01 /MIR /NP
robocopy \_calentamientoglobalacelerado.net i:\_calentamientoglobalacelerado.net /MIR /NP
robocopy \_calentamientoglobalacelerado.net f:\_calentamientoglobalacelerado.net /MIR /NP

robocopy H:\ F:\ ecosistema-marafd-completo.zip /XO

echo Fin OK ...