#lang "fb"

' local_SHA.bas
' Tecnologia de Código Abierto MARAFd - Comparador local - servidor de inventarios SHA256
' Idea original: Rafael Lomena - MaRaF SOFT
' Autor codigo: Original por ChatGPT, modificado por Claude y autor                               
' https://calentamientoglobalacelerado.net/MARAFd/
' Compilado en FreeBASIC 1.8 (GCC) - Windows

Type SHA_Record
    ruta As String
    sha  As String
End Type

Const LOCAL_JSON          As String = "local_SHA.json"
Const WEB_JSON            As String = "web_SHA.json"

Const REPORT_FILE         As String = "compare_SHA_report.txt"
Const ONLY_LOCAL_FILE     As String = "compare_SHA_solo_local.txt"
Const ONLY_WEB_FILE       As String = "compare_SHA_solo_web.txt"
Const DIFFERENT_FILE      As String = "compare_SHA_distintos.txt"
Const DUP_LOCAL_FILE      As String = "compare_SHA_duplicados_local.txt"
Const DUP_WEB_FILE        As String = "compare_SHA_duplicados_web.txt"

Const PROGRESS_EVERY      As Integer = 500
Const SORT_CASE_SENSITIVE As Integer = 1

Dim Shared gReportFN As Integer
Dim Shared gOnlyLocalFN As Integer
Dim Shared gOnlyWebFN As Integer
Dim Shared gDifferentFN As Integer
Dim Shared gDupLocalFN As Integer
Dim Shared gDupWebFN As Integer

Function ReplaceAll(ByVal txt As String, ByVal findText As String, ByVal replText As String) As String
    Dim p As Integer
    Dim outText As String
    Dim restText As String

    If Len(findText) = 0 Then
        ReplaceAll = txt
        Exit Function
    End If

    restText = txt
    outText = ""

    Do
        p = InStr(restText, findText)
        If p = 0 Then
            outText = outText & restText
            Exit Do
        End If

        outText = outText & Left(restText, p - 1) & replText
        restText = Mid(restText, p + Len(findText))
    Loop

    ReplaceAll = outText
End Function

Function NormalizePath(ByVal s As String) As String
    Dim t As String

    t = Trim(s)
    t = ReplaceAll(t, "\", "/")

    Do While InStr(t, "//") > 0
        t = ReplaceAll(t, "//", "/")
    Loop

    Do While Len(t) > 0 And Left(t, 1) = "/"
        t = Mid(t, 2)
    Loop

    NormalizePath = t
End Function

Function NormalizeSHA(ByVal s As String) As String
    Dim t As String

    t = LCase(Trim(s))
    t = ReplaceAll(t, Chr(13), "")
    t = ReplaceAll(t, Chr(10), "")
    t = ReplaceAll(t, Chr(9), "")
    t = ReplaceAll(t, " ", "")
    t = ReplaceAll(t, Chr(34), "")
    t = ReplaceAll(t, ",", "")
    t = ReplaceAll(t, "}", "")
    t = ReplaceAll(t, "]", "")

    NormalizeSHA = t
End Function

Function IsHexLowerChar(ByVal ch As String) As Integer
    If Len(ch) <> 1 Then
        IsHexLowerChar = 0
        Exit Function
    End If

    If (ch >= "0" And ch <= "9") Or (ch >= "a" And ch <= "f") Then
        IsHexLowerChar = -1
    Else
        IsHexLowerChar = 0
    End If
End Function

Function IsValidSHA256(ByVal s As String) As Integer
    Dim t As String
    Dim i As Integer

    t = NormalizeSHA(s)

    If Len(t) <> 64 Then
        IsValidSHA256 = 0
        Exit Function
    End If

    For i = 1 To 64
        If IsHexLowerChar(Mid(t, i, 1)) = 0 Then
            IsValidSHA256 = 0
            Exit Function
        End If
    Next i

    IsValidSHA256 = -1
End Function

Function JsonValueFromLine(ByVal lineText As String, ByVal keyName As String) As String
    Dim marker As String
    Dim p1 As Integer
    Dim i As Integer
    Dim outv As String
    Dim ch As String
    Dim esc As Integer

    marker = Chr(34) & keyName & Chr(34) & ":" & Chr(34)
    p1 = InStr(lineText, marker)
    If p1 = 0 Then
        JsonValueFromLine = ""
        Exit Function
    End If

    p1 = p1 + Len(marker)
    outv = ""
    esc = 0

    For i = p1 To Len(lineText)
        ch = Mid(lineText, i, 1)

        If esc = 1 Then
            Select Case ch
            Case Chr(34)
                outv = outv & Chr(34)
            Case "\"
                outv = outv & "\"
            Case "/"
                outv = outv & "/"
            Case "b"
                outv = outv & Chr(8)
            Case "f"
                outv = outv & Chr(12)
            Case "n"
                outv = outv & Chr(10)
            Case "r"
                outv = outv & Chr(13)
            Case "t"
                outv = outv & Chr(9)
            Case Else
                outv = outv & ch
            End Select
            esc = 0
        Else
            If ch = "\" Then
                esc = 1
            ElseIf ch = Chr(34) Then
                Exit For
            Else
                outv = outv & ch
            End If
        End If
    Next i

    JsonValueFromLine = outv
End Function

Function ComparePaths(ByRef a As String, ByRef b As String) As Integer
    If SORT_CASE_SENSITIVE <> 0 Then
        If a < b Then
            ComparePaths = -1
        ElseIf a > b Then
            ComparePaths = 1
        Else
            ComparePaths = 0
        End If
    Else
        Dim aa As String
        Dim bb As String

        aa = LCase(a)
        bb = LCase(b)

        If aa < bb Then
            ComparePaths = -1
        ElseIf aa > bb Then
            ComparePaths = 1
        Else
            ComparePaths = 0
        End If
    End If
End Function

Sub SwapRecords(ByRef a As SHA_Record, ByRef b As SHA_Record)
    Dim tr As String
    Dim ts As String

    tr = a.ruta
    ts = a.sha

    a.ruta = b.ruta
    a.sha  = b.sha

    b.ruta = tr
    b.sha  = ts
End Sub

Sub QuickSortRecords(arr() As SHA_Record, ByVal firstIdx As Integer, ByVal lastIdx As Integer)
    Dim i As Integer
    Dim j As Integer
    Dim pivot As String

    i = firstIdx
    j = lastIdx
    pivot = arr((firstIdx + lastIdx) \ 2).ruta

    While i <= j
        While ComparePaths(arr(i).ruta, pivot) < 0
            i = i + 1
        Wend

        While ComparePaths(arr(j).ruta, pivot) > 0
            j = j - 1
        Wend

        If i <= j Then
            SwapRecords(arr(i), arr(j))
            i = i + 1
            j = j - 1
        End If
    Wend

    If firstIdx < j Then QuickSortRecords(arr(), firstIdx, j)
    If i < lastIdx Then QuickSortRecords(arr(), i, lastIdx)
End Sub

Sub AddRecord(arr() As SHA_Record, ByRef n As Integer, ByVal ruta As String, ByVal sha As String)
    If n = 0 Then
        ReDim arr(1 To 1)
        n = 1
    Else
        n = n + 1
        ReDim Preserve arr(1 To n)
    End If

    arr(n).ruta = NormalizePath(ruta)
    arr(n).sha  = NormalizeSHA(sha)
End Sub

Function FileExistsFB(ByVal fileName As String) As Integer
    Dim fn As Integer
    fn = FreeFile

    If Open(fileName For Input Access Read As #fn) = 0 Then
        Close #fn
        FileExistsFB = -1
    Else
        FileExistsFB = 0
    End If
End Function

Function LoadInventory(ByVal fileName As String, arr() As SHA_Record, ByRef countOut As Integer, ByRef invalidSHA As Integer) As Integer
    Dim fn As Integer
    Dim lineText As String
    Dim ruta As String
    Dim sha  As String
    Dim loaded As Integer

    countOut = 0
    invalidSHA = 0
    loaded = 0
    fn = FreeFile

    If Open(fileName For Input Access Read As #fn) <> 0 Then
        LoadInventory = 0
        Exit Function
    End If

    While Not Eof(fn)
        Line Input #fn, lineText

        If InStr(lineText, Chr(34) & "ruta_relativa" & Chr(34)) > 0 Then
            ruta = JsonValueFromLine(lineText, "ruta_relativa")
            sha  = JsonValueFromLine(lineText, "sha256")
            If Len(sha) = 0 Then sha = JsonValueFromLine(lineText, "SHA256")
            If Len(sha) = 0 Then sha = JsonValueFromLine(lineText, "sha")

            If Len(ruta) > 0 Then
                ruta = NormalizePath(ruta)
                sha = NormalizeSHA(sha)

                If Len(sha) > 0 And IsValidSHA256(sha) = 0 Then
                    invalidSHA = invalidSHA + 1
                End If

                AddRecord(arr(), countOut, ruta, sha)
                loaded = loaded + 1

                If (loaded Mod PROGRESS_EVERY) = 0 Then
                    Print "Cargados desde "; fileName; ": "; loaded
                End If
            End If
        End If
    Wend

    Close #fn
    LoadInventory = -1
End Function

Function SafeOpenOutput(ByVal fileName As String, ByRef fileNo As Integer) As Integer
    fileNo = FreeFile
    SafeOpenOutput = Open(fileName For Output Access Write As #fileNo)
End Function

Sub WriteReportLine(ByVal s As String)
    Print #gReportFN, s
End Sub

Sub CompactSortedKeepLast(ByRef labelName As String, arrIn() As SHA_Record, ByVal nIn As Integer, arrOut() As SHA_Record, ByRef nOut As Integer, ByVal dupFN As Integer, ByRef dupCount As Integer)
    Dim i As Integer
    Dim currentRuta As String
    Dim currentSha As String
    Dim seenOne As Integer

    nOut = 0
    dupCount = 0
    seenOne = 0

    For i = 1 To nIn
        If seenOne = 0 Then
            currentRuta = arrIn(i).ruta
            currentSha  = arrIn(i).sha
            seenOne = -1
        Else
            If ComparePaths(arrIn(i).ruta, currentRuta) = 0 Then
                dupCount = dupCount + 1
                Print #dupFN, labelName & " | " & currentRuta & " | ANTERIOR=" & currentSha & " | NUEVO=" & arrIn(i).sha
                currentSha = arrIn(i).sha
            Else
                AddRecord(arrOut(), nOut, currentRuta, currentSha)
                currentRuta = arrIn(i).ruta
                currentSha  = arrIn(i).sha
            End If
        End If
    Next i

    If seenOne <> 0 Then
        AddRecord(arrOut(), nOut, currentRuta, currentSha)
    End If
End Sub

Sub CompareInventories(localArr() As SHA_Record, ByVal nLocal As Integer, webArr() As SHA_Record, ByVal nWeb As Integer)
    Dim i As Integer
    Dim j As Integer
    Dim cmp As Integer
    Dim onlyLocal As Integer
    Dim onlyWeb As Integer
    Dim different As Integer
    Dim equalCnt As Integer
    Dim matchedPaths As Integer

    i = 1
    j = 1
    onlyLocal = 0
    onlyWeb = 0
    different = 0
    equalCnt = 0
    matchedPaths = 0

    While i <= nLocal And j <= nWeb
        cmp = ComparePaths(localArr(i).ruta, webArr(j).ruta)

        If cmp = 0 Then
            matchedPaths = matchedPaths + 1

            If localArr(i).sha = webArr(j).sha Then
                equalCnt = equalCnt + 1
            Else
                different = different + 1
                Print #gDifferentFN, localArr(i).ruta & " | LOCAL=" & localArr(i).sha & " | WEB=" & webArr(j).sha
            End If

            i = i + 1
            j = j + 1

        ElseIf cmp < 0 Then
            onlyLocal = onlyLocal + 1
            Print #gOnlyLocalFN, localArr(i).ruta & " | " & localArr(i).sha
            i = i + 1

        Else
            onlyWeb = onlyWeb + 1
            Print #gOnlyWebFN, webArr(j).ruta & " | " & webArr(j).sha
            j = j + 1
        End If

        If ((i + j) Mod PROGRESS_EVERY) = 0 Then
            Print "Comparando... emparejadas="; matchedPaths; " ok="; equalCnt; " diff="; different
        End If
    Wend

    While i <= nLocal
        onlyLocal = onlyLocal + 1
        Print #gOnlyLocalFN, localArr(i).ruta & " | " & localArr(i).sha
        i = i + 1
    Wend

    While j <= nWeb
        onlyWeb = onlyWeb + 1
        Print #gOnlyWebFN, webArr(j).ruta & " | " & webArr(j).sha
        j = j + 1
    Wend

    WriteReportLine("Resumen comparacion")
    WriteReportLine("rutas_emparejadas=" & LTrim(Str(matchedPaths)))
    WriteReportLine("local_total_unicos=" & LTrim(Str(nLocal)))
    WriteReportLine("web_total_unicos=" & LTrim(Str(nWeb)))
    WriteReportLine("coinciden_sha=" & LTrim(Str(equalCnt)))
    WriteReportLine("solo_local=" & LTrim(Str(onlyLocal)))
    WriteReportLine("solo_web=" & LTrim(Str(onlyWeb)))
    WriteReportLine("sha_distinto=" & LTrim(Str(different)))
End Sub

Sub WriteHeader()
    WriteReportLine("compare_SHA_v8.bas - MARAFd")
    WriteReportLine("Entrada local: " & LOCAL_JSON)
    WriteReportLine("Entrada web  : " & WEB_JSON)
    WriteReportLine("Salida reporte         : " & REPORT_FILE)
    WriteReportLine("Salida solo local      : " & ONLY_LOCAL_FILE)
    WriteReportLine("Salida solo web        : " & ONLY_WEB_FILE)
    WriteReportLine("Salida distintos       : " & DIFFERENT_FILE)
    WriteReportLine("Salida duplicados local: " & DUP_LOCAL_FILE)
    WriteReportLine("Salida duplicados web  : " & DUP_WEB_FILE)
    WriteReportLine(String(70, 45))
End Sub

Dim localRaw() As SHA_Record
Dim webRaw()   As SHA_Record
Dim localArr() As SHA_Record
Dim webArr()   As SHA_Record

Dim nLocalRaw As Integer
Dim nWebRaw   As Integer
Dim nLocal As Integer
Dim nWeb   As Integer
Dim invalidLocal As Integer
Dim invalidWeb As Integer
Dim dupLocal As Integer
Dim dupWeb As Integer

Print "=================================================="
Print " compare_SHA_v8.bas - MARAFd"
Print " Comparador local vs web"
Print "=================================================="

If SafeOpenOutput(REPORT_FILE, gReportFN) <> 0 Then End
If SafeOpenOutput(ONLY_LOCAL_FILE, gOnlyLocalFN) <> 0 Then End
If SafeOpenOutput(ONLY_WEB_FILE, gOnlyWebFN) <> 0 Then End
If SafeOpenOutput(DIFFERENT_FILE, gDifferentFN) <> 0 Then End
If SafeOpenOutput(DUP_LOCAL_FILE, gDupLocalFN) <> 0 Then End
If SafeOpenOutput(DUP_WEB_FILE, gDupWebFN) <> 0 Then End

If FileExistsFB(LOCAL_JSON) = 0 Then
    Print "ERROR: no existe "; LOCAL_JSON
    End
End If

If FileExistsFB(WEB_JSON) = 0 Then
    Print "ERROR: no existe "; WEB_JSON
    End
End If

WriteHeader()

Print "Cargando "; LOCAL_JSON; " ..."
If LoadInventory(LOCAL_JSON, localRaw(), nLocalRaw, invalidLocal) = 0 Then End

Print "Cargando "; WEB_JSON; " ..."
If LoadInventory(WEB_JSON, webRaw(), nWebRaw, invalidWeb) = 0 Then End

WriteReportLine("local_cargados_bruto=" & LTrim(Str(nLocalRaw)))
WriteReportLine("web_cargados_bruto=" & LTrim(Str(nWebRaw)))
WriteReportLine("local_sha_invalidos=" & LTrim(Str(invalidLocal)))
WriteReportLine("web_sha_invalidos=" & LTrim(Str(invalidWeb)))

If nLocalRaw > 1 Then
    Print "Ordenando inventario local..."
    QuickSortRecords(localRaw(), 1, nLocalRaw)
End If

If nWebRaw > 1 Then
    Print "Ordenando inventario web..."
    QuickSortRecords(webRaw(), 1, nWebRaw)
End If

Print "Compactando duplicados local..."
CompactSortedKeepLast("LOCAL", localRaw(), nLocalRaw, localArr(), nLocal, gDupLocalFN, dupLocal)

Print "Compactando duplicados web..."
CompactSortedKeepLast("WEB", webRaw(), nWebRaw, webArr(), nWeb, gDupWebFN, dupWeb)

WriteReportLine("local_duplicados=" & LTrim(Str(dupLocal)))
WriteReportLine("web_duplicados=" & LTrim(Str(dupWeb)))
WriteReportLine("local_cargados_unicos=" & LTrim(Str(nLocal)))
WriteReportLine("web_cargados_unicos=" & LTrim(Str(nWeb)))
WriteReportLine(String(70, 45))

Print "Comparando inventarios..."
CompareInventories(localArr(), nLocal, webArr(), nWeb)

WriteReportLine(String(70, 45))
WriteReportLine("Fin de proceso")

Close #gDupWebFN
Close #gDupLocalFN
Close #gDifferentFN
Close #gOnlyWebFN
Close #gOnlyLocalFN
Close #gReportFN

Print "Proceso finalizado."
Print "Reporte: "; REPORT_FILE
Print "Solo local: "; ONLY_LOCAL_FILE
Print "Solo web: "; ONLY_WEB_FILE
Print "SHA distintos: "; DIFFERENT_FILE
Print "Duplicados local: "; DUP_LOCAL_FILE
Print "Duplicados web: "; DUP_WEB_FILE
