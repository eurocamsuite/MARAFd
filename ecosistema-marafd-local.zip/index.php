﻿<?php
// PROYECTO: MARAFd - GESTION INTELIGENTE DE FONDOS DOCUMENTALES DIGITALES BASADA EN TESAURO                     
// Ecosistema tecnologia: MARAFd (c)(c) 2025
// Proceso en servidor: index.php by MARAFd - TECNOLOGIA PARA LA GESTION DE FONDOS DOCUMENTALES DIGITALES
// Creative Commons Attribution-NonCommercial-ShareAlike 4.0 - 06/02/2025 - Num.reg. 2502060809787          
// OPEN SOURCE SOLUTION by RAFAEL LOMENA VARO - MARAF SOFT 1993 ©© 2026    
// Idea original: Rafael Lomena - MaRaF SOFT
// Autor código: Original por ChatGPT, modificado por DeepSeek, Claude y autor idea
// https://calentamientoglobalacelerado.net/MARAFd/
//
// Program: index.php 
// PHP version: 8.3
// Fecha: 30/04/2025      
// Autor código: Original por ChatGPT, modificado por DeepSeek, Claude y autor idea
// Idea original: Rafael Lomena - MaRaF SOFT
// Ecosistema tecnologia: MARAFd (c)(c) 2025                                
// Descripcion: codigo PHP para generacion de pagina HTML con el contenido completo del fondo documental
// y enlaces dinámicos intrapáginas a carpetas y subcarpetas y enlaces de acceso online a archivos del fondo

// FLUJO BASICO DEL PROCESO index.php
//    Se crea pagina HTML hiperenlaces directo a carpetas y documentos

// Función para convertir bytes a megabytes
function tamanoEnMB($bytes) {
    return number_format($bytes / 1048576, 2) . ' MB';
}

// Función recursiva para obtener la lista de archivos y carpetas
function obtenerArchivosRecursivos($directorio, &$archivos, &$carpetas, $nivel = 0) {
    $elementos = scandir($directorio);
    foreach ($elementos as $elemento) {
        if ($elemento !== '.' && $elemento !== '..') {
            $rutaCompleta = $directorio . '/' . $elemento;
            if (is_dir($rutaCompleta)) {
                if (strtolower($elemento) !== 'taller' && strtolower($elemento) !== 'img') {
                    $carpetas[] = $rutaCompleta;
                    obtenerArchivosRecursivos($rutaCompleta, $archivos, $carpetas, $nivel + 1);
                }
            } else {
                if ($nivel > 0) {
                    $archivos[] = $rutaCompleta;
                }
            }
        }
    }
}

// Directorio principal
$directorioPrincipal = __DIR__;
$archivos = [];
$carpetas = [];
obtenerArchivosRecursivos($directorioPrincipal, $archivos, $carpetas, 1);

// Generar HTML
$nombreArchivoHTML = 'lista_archivos.html';
$archivoHTML = fopen($nombreArchivoHTML, 'w');

// URL base para los enlaces
$urlBase = 'https://calentamientoglobalacelerado.net/ebiblio_melilla_riff';

// Construir contenido HTML
$htmlContent = "<!DOCTYPE html>
<html lang='es'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Proyecto abierto Fondo Documental Digital sobre Melilla y el Riff</title>
    <style>
        /* Modificación 1: Centrado de cabecera */
        .header-container {
            display: flex;
            justify-content: center;
            padding: 20px 0;
        }

        /* Nuevos estilos para estructura de árbol */
        .tree-container {
            position: relative;
            margin-left: 30px;
        }

        .tree-node {
            position: relative;
            padding-left: 40px;
            margin: 12px 0;
        }

        .tree-node::before {
            content: '';
            position: absolute;
            left: -15px;
            top: 50%;
            width: 30px;
            border-bottom: 2px dotted #bdc3c7;
        }

        .tree-node::after {
            content: '';
            position: absolute;
            left: -15px;
            top: -50%;
            bottom: 50%;
            width: 2px;
            background: repeating-linear-gradient(
                to bottom,
                #bdc3c7 0,
                #bdc3c7 3px,
                transparent 3px,
                transparent 6px
            );
        }

        /* Estilos originales preservados */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            background: #f8f9fa;
            color: #2c3e50;
        }
        
        #indice {
            background: #fff;
            padding: 20px;
            margin: 20px auto;
            max-width: 800px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }
        
        a {
            color: #2980b9;
            text-decoration: none;
            transition: all 0.2s;
        }
        
        a:hover {
            text-decoration: underline;
            background: #f0f8ff;
        }
        
        hr {
            border-color: rgba(0,0,0,0.1);
        }
        
        footer {
            background: #2c3e50;
            color: #fff;
            padding: 20px;
            margin-top: 40px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class='header-container'>
        <a href='https://calentamientoglobalacelerado.net/fondo_documental_Melilla_Riff'>
            <img src='img/cabecera_fondo_documental_melilla_riff.jpg' alt='Cabecera' style='max-width:90%; height:auto;'>
        </a>
    </div>

    <div id='indice'>
        <h2 style='color: #666; border-bottom: 2px solid #eee; padding-bottom: 10px;'><center>COMO UTILIZAR ESTA PÁGINA</center></h2>
        <ul style='list-style: none; padding: 0;'>
            <li>🔍 Use el buscador de palabras del navegador (Ctrl+F)</li>
            <li>▶️ Algunos navegadores reproducen archivos multimedia directamente (Mozilla, Edge, etc.)</li>
            <li>💾 Descargue solo los documentos que necesite y apoye al autor de este ímprobo trabajo</li>
        </ul>
	</div>
    <hr style='width: 70%; margin: 30px auto;'>";
	$htmlContent .= "
	<h2 style='color: #999; border-bottom: 2px solid #eee; padding-bottom: 12px;'>&nbsp;&nbsp;&nbsp;INDICE PROVISIONAL DE CARPETAS :</h2>
	";
	// Listado de carpetas con estructura de árbol
foreach ($carpetas as $carpeta) {
    $carpetaRelativa = str_replace($directorioPrincipal, '', $carpeta);
    $carpetaId = rawurlencode($carpetaRelativa);
    $nivelAnidacion = substr_count($carpetaRelativa, '/');
    $marginLeft = $nivelAnidacion * 30;

    $htmlContent .= "
    <div class='tree-container' style='margin-left: {$marginLeft}px;'>
        <div class='tree-node'>
            <img src='folder-lit-marron.gif' alt='Carpeta' style='width:48px; vertical-align: middle;'>
            <a href='#{$carpetaId}'>".htmlspecialchars(basename($carpeta))."</a>
        </div>
    </div>";
}

$htmlContent .= "<hr style='border-color: #3498db; margin: 30px auto; width: 70%;'>";

// Listado detallado de carpetas
foreach ($carpetas as $carpeta) {
    $carpetaRelativa = str_replace($directorioPrincipal, '', $carpeta);
    $carpetaId = rawurlencode($carpetaRelativa);

    $htmlContent .= "
    <h2 id='{$carpetaId}' style='padding: 15px; background: #f8f9fa; border-radius: 4px;'>
        <img src='folder.gif' alt='Carpeta' style='width:64px; vertical-align: middle;'>
        ".htmlspecialchars($carpetaRelativa)."
        <a href='#indice' style='font-size: 0.9em; float: right;'>[Volver al índice]</a>
    </h2>";

    // Subcarpetas con líneas de conexión
    $subcarpetas = array_filter($carpetas, function($sub) use ($carpeta) {
        return dirname($sub) === $carpeta;
    });

    if (!empty($subcarpetas)) {
        $htmlContent .= "<div class='tree-container' style='margin-left: 60px;'>";
        $htmlContent .= "<h3 style='color: #2c3e50;'>SUBCARPETAS</h3>";
        foreach ($subcarpetas as $sub) {
            $subRelativa = str_replace($directorioPrincipal, '', $sub);
            $htmlContent .= "
            <div class='tree-node'>
                <img src='folder.gif' alt='Carpeta' style='width:36px; vertical-align: middle;'>
                <a href='#".rawurlencode($subRelativa)."'>".htmlspecialchars(basename($sub))."</a>
            </div>";
        }
        $htmlContent .= "</div>";
    }

    // Archivos (código original preservado)
    $archivosEnCarpeta = array_filter($archivos, function($archivo) use ($carpeta) {
        return dirname($archivo) === $carpeta;
    });

    if (!empty($archivosEnCarpeta)) {
        $htmlContent .= "<div style='margin-left: 60px;'>";
        $htmlContent .= "<h3 style='color: #2c3e50;'>ARCHIVOS</h3>";
        foreach ($archivosEnCarpeta as $archivo) {
            $archivoRelativo = str_replace($directorioPrincipal, $urlBase, $archivo);
            $nombreArchivo = htmlspecialchars(basename($archivo));
            $tamano = tamanoEnMB(filesize($archivo));
            $extension = strtolower(substr($archivo, strrpos($archivo, '.')));

            $htmlContent .= "<p style='margin: 8px 0;'>";
            
            switch ($extension) {
                case '.pdf': $htmlContent .= "<img src='img/pdf.gif' alt='PDF' style='width:14px; margin-right:8px;'>"; break;
                case '.epub': $htmlContent .= "<img src='img/epub.gif' alt='EPUB' style='width:14px; margin-right:8px;'>"; break;
                case '.jpg': case '.bmp': case '.gif': case '.png': case '.jpeg':
                    $htmlContent .= "<img src='img/img.gif' alt='IMG' style='width:14px; margin-right:8px;'>"; break;
                case '.txt': case '.doc': case '.odt': case '.docx':
                    $htmlContent .= "<img src='img/doc2.gif' alt='DOC' style='width:14px; margin-right:8px;'>"; break;
                case '.ppt': case '.pptx': $htmlContent .= "<img src='img/img2.gif' alt='PPT' style='width:14px; margin-right:8px;'>"; break;
                case '.mp3': case '.wav': case '.m4a': $htmlContent .= "<img src='img/audio.gif' alt='AUDIO' style='width:14px; margin-right:8px;'>"; break;
                case '.avi': case '.mp4': $htmlContent .= "<img src='img/img2.gif' alt='VIDEO' style='width:14px; margin-right:8px;'>"; break;
                default: $htmlContent .= "<img src='img/doc2.gif' alt='DOC' style='width:14px; margin-right:8px;'>";
            }

            $htmlContent .= "<a href='".htmlspecialchars($archivoRelativo)."' target='_blank'>{$nombreArchivo}</a>
                <span style='color: #777; font-size:0.9em;'>({$tamano})</span>
            </p>";
        }
        $htmlContent .= "</div>";
    }
    $htmlContent .= "<hr style='margin: 30px auto; width: 70%;'>";
}

// Pie de página
$htmlContent .= "
<footer>
    <p>Fondo Documental Digital Abierto MELILLA-RIFF</p>
    <p>https://calentamientoglobalacelerado.net/fondo_documental_Melilla_Riff/</p>
    <p><hr></p>
	<p>Fondo Documental Digital restringido PROTOHISTORIA MEDITERRANEO OCCIDENTAL</p>
    <p>https://calentamientoglobalacelerado.net/ebiblio_historia_antigua_01/</p>
	<p><hr></p>
	<p>Administrador único de ambos fondos: Rafael Lomena Varo</p>
	<p>Tecnología MARAFd utilizada en ambos fondos</p>
	<p><a href='https://calentamientoglobalacelerado.net/marafd/'>Web oficial de MARAFd</a></p>
    <p>Contacto: <a href='mailto:eurocamsuite@yahoo.es' style='color:#85C1E9;'>eurocamsuite@yahoo.es</a></p>
	<p><hr></p>
    <p>2022 © © 2025 MARAFd Technology</p>
</footer>
</body>
</html>";

fwrite($archivoHTML, $htmlContent);
fclose($archivoHTML);

// Mensaje final
$totalArchivos = count($archivos);
$totalCarpetas = count($carpetas);
$fechaActual = date("Y-m-d H:i:s");

echo "<div style='
    font-family: \"Courier New\", monospace;
    color: #666;
    background: #fff;
    padding: 20px;
    border-radius: 5px;
    max-width: 600px;
    margin: 20px auto;
    text-align: center;
    white-space: pre;
'>
*************************************
*  Generador de enlaces URLs v1.4   *
*  FONDO DOCUMENTAL MELILLA - RIF   *
*  MARAFd Technology - 2022©©2025 *
*************************************
 Pulse enlace a archivo HTML generado:
*************************************
· Total archivos: $totalArchivos
· Total carpetas: $totalCarpetas
· Fecha  reporte: $fechaActual
· HTML  generado: <b><a href='$nombreArchivoHTML' style='color:#2C3E50; text-decoration:underline;'>$nombreArchivoHTML</a></b>
</div>";
?>