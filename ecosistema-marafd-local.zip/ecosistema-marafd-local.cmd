@echo off
echo $ Empaquetado del ecosistema MARAFd desde directorio local ...
echo $ de ecosistema-marafd-local.zip
 
REM refresca listado de archivos para empaquetar, excluyendo upload_script.txt

dir /b /a:-d *.* | findstr /v /i "^upload_script\.txt$" > ecosistema-marafd-local
 
REM espera un poco antes de seguir
REM timeout /t 2
 
REM Comprobar si ecosistema-marafd-local existe

 if not exist ecosistema-marafd-local (
     echo El archivo ecosistema-marafd-local no existe.
     exit /b 1
 )
 
REM Construir la lista de archivos desde ecosistema-marafd-local
 setlocal EnableDelayedExpansion
 set "fileList="
 for /f "usebackq delims=" %%a in ("ecosistema-marafd-local") do (
     set "fileList=!fileList! %%a"
 )
 endlocal & set "fileList=%fileList%"
 
REM Crear el ZIP usando tar (requiere Windows 10 o superior). Este ZIP ...
REM Incluye también las carpetas IMG y CSS, JS completas si están en el directorio
 tar -a -c -f ecosistema-marafd-local.zip %fileList% css js img

REM espera un poco antes de seguir
timeout /t 2

 if exist ecosistema-marafd-local.zip (
     echo Archivo ecosistema-marafd-local.zip creado correctamente.
 ) else (
     echo Error al crear el archivo ZIP.
 )
