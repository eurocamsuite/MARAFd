' PROYECTO: MARAFd - GESTION INTELIGENTE DE FONDOS DOCUMENTALES DIGITALES BASADA EN TESAURO                     
' Ecosistema tecnologia: MARAFd (c)(c) 2025
' ToolKit: compacTIA.bas by MARAFd - TECNOLOGIA PARA LA GESTION DE FONDOS DOCUMENTALES DIGITALES
' Creative Commons Attribution-NonCommercial-ShareAlike 4.0 - 06/02/2025 - Num.reg. 2502060809787          
' OPEN SOURCE SOLUTION by RAFAEL LOMENA VARO - MARAF SOFT 1993 ©© 2025    
' Idea original: Rafael Lomena - MaRaF SOFT
' Autor código: Original por ChatGPT, modificado por Claude y autor                               
' https://calentamientoglobalacelerado.net/MARAFd/
'
' Program: compacTIA.bas 
' Version: 1.1 for WINDOWS x64                                                                 
' Fecha: 07/04/2025      
' Autor: Original por ChatGPT, modificado por Claude y autor idea 
' Idea original: Rafael Lomena - MaRaF SOFT
' Ecosistema tecnologia: MARAFd (c)(c) 2025                                
'
' Descripcion: Compacta indice tesauro segun archivo de configuraciones compacTIA.asc
'
' Compilador: FreeBASIC (v1.08.1) GCC-9.3.0
' Compilado-linkado: fbc64 compacTIA.bas -s console (resultante compacTIA.exe)
'
' FLUJO DEL PROCESO:
' Se lee fichero de configuracion "compacTIA.asc" que debe estar en mismo directorio
'    el archivo de configuracion especifica las extensiones a omitir del tesauro original 
'    se lee tesauro "indice-tesauro.txt"
'    Se criba y genera "indice-tesauro_compacto.txt" 
'    Se criba y elimina url base del path y genera "indice-tesauro_compacto2.txt"
'    Se crea reporte con resultados del proceso en "cTIA_tesauro_report.txt"


#Include "file.bi"

Dim linea As String, baseUrl As String
Dim excluirExtensiones(100) As String
Dim numExtensiones As Integer = 0
Dim inputFile As Integer = FreeFile
Dim outputFile1 As Integer = FreeFile + 1
Dim outputFile2 As Integer = FreeFile + 2
Dim configfile As Integer = FreeFile + 3
Dim reportFile As Integer = FreeFile + 4
Dim extension As String
Dim i As Integer
Dim skipLine As Boolean
Dim tieneExtension As Boolean
Dim ultimaParte As String
Dim ultimoSlash As Integer

' Variables para estadísticas del reporte
Dim lineasLeidas As Integer = 0
Dim lineasExcluidas As Integer = 0
Dim tamanyoOriginal As Long
Dim tamanyoCompacto1 As Long
Dim tamanyoCompacto2 As Long
Dim fechaActual As String
Dim horaActual As String
Dim reportContent As String
Dim archivoEntrada As String = "indice-tesauro.txt"
Dim archivoSalida1 As String = "indice-tesauro_compacto.txt"
Dim archivoSalida2 As String = "indice-tesauro_compacto2.txt"
Dim archivoReporte As String = "cTIA_tesauro_report.txt"

Function Replace(ByRef texto As String, ByRef buscar As String, ByRef reemplazar As String) As String
    Dim resultado As String = ""
    Dim p As Integer = 1, np As Integer

    Do
        np = InStr(p, texto, buscar)
        If np = 0 Then
            resultado += Mid(texto, p)
            Exit Do
        End If
        resultado += Mid(texto, p, np - p) + reemplazar
        p = np + Len(buscar)
    Loop

    Return resultado
End Function

' FunciOn para obtener la fecha actual en formato dd/mm/aaaa
Function ObtenerFechaActual() As String
    Dim fechaStr As String = Date
    ' En FreeBASIC, Date devuelve la fecha en formato "mm-dd-yyyy"
    Dim mes As String = Left(fechaStr, 2)
    Dim dia As String = Mid(fechaStr, 4, 2)
    Dim anyo As String = Right(fechaStr, 4)
    Return dia & "/" & mes & "/" & anyo
End Function

' FunciOn para obtener la hora actual en formato hh:mm
Function ObtenerHoraActual() As String
    Dim horaStr As String = Time
    ' En FreeBASIC, Time devuelve la hora en formato "hh:mm:ss"
    Return Left(horaStr, 5)  ' Tomamos solo las horas y minutos
End Function

' FunciOn para obtener el tamanyo de un archivo en KB
Function ObtenerTamanyoKB(archivo As String) As Long
    Dim tamanyo As LongInt
    
    tamanyo = FileLen(archivo)
    Return tamanyo \ 1024 + IIf(tamanyo Mod 1024 > 0, 1, 0)
End Function

' Leer configuraciones desde compacTIA.asc
Open "compacTIA.asc" For Input As #configfile
While Not EOF(configfile)
    Line Input #configfile, linea
    linea = Trim(linea)
    If linea = "" Or Left(linea, 1) = "#" Then
        Continue While
    ElseIf Left(linea, 1) = "." Then
        ' Guardar extensiones en minUsculas para comparaciOn insensible a mayUsculas/minUsculas
        excluirExtensiones(numExtensiones) = LCase(linea)
        numExtensiones += 1
    ElseIf Left(linea, 4) = "http" Then
        baseUrl = linea
    End If
Wend
Close #configfile

' Procesar el archivo indice-tesauro.txt
Open archivoEntrada For Input As #inputFile
Open archivoSalida1 For Output As #outputFile1
Open archivoSalida2 For Output As #outputFile2

While Not EOF(inputFile)
    Line Input #inputFile, linea
    lineasLeidas += 1
    skipLine = False
    tieneExtension = False
    
    ' Obtener la Ultima parte del URL para verificar si tiene extensiOn
    ultimoSlash = InStrRev(linea, "/")
    If ultimoSlash > 0 Then
        ultimaParte = Mid(linea, ultimoSlash + 1)
        ' Verificar si la Ultima parte tiene un punto (indicando una extensiOn)
        If InStr(ultimaParte, ".") > 0 Then
            tieneExtension = True
        End If
    End If
    
    ' Saltar líneas sin extensiOn (directorios)
    If Not tieneExtension Then
        skipLine = True
        lineasExcluidas += 1
    Else
        ' Verificar si la línea contiene alguna extensión a excluir
        For i = 0 To numExtensiones - 1
            extension = excluirExtensiones(i)
            ' Hacer comparación insensible a mayúsculas/minúsculas
            If InStr(LCase(linea), extension) > 0 Then
                skipLine = True
                lineasExcluidas += 1
                Exit For
            End If
        Next i
    End If
    
    If Not skipLine Then
        Print #outputFile1, linea
        ' Además eliminar la base URL para compacto2
        linea = Replace(linea, baseUrl, "")
        Print #outputFile2, linea
    End If
Wend

Close #inputFile
Close #outputFile1
Close #outputFile2

' Obtener fechas y tamayos para el reporte
fechaActual = ObtenerFechaActual()
horaActual = ObtenerHoraActual()
tamanyoOriginal = ObtenerTamanyoKB(archivoEntrada)
tamanyoCompacto1 = ObtenerTamanyoKB(archivoSalida1)
tamanyoCompacto2 = ObtenerTamanyoKB(archivoSalida2)

' Generar el reporte
Open archivoReporte For Output As #reportFile
Print #reportFile, " ======================================================="
Print #reportFile, " TECNOLOGIA MARAFD 2025"
Print #reportFile, " REPORTE DE compacTIA"
Print #reportFile, " INDICE TESAURO ORIGINAL: " & archivoEntrada
Print #reportFile, " FECHA: " & fechaActual
Print #reportFile, " HORA: " & horaActual
Print #reportFile, " -------------------------------------------------------"
Print #reportFile, "Extensiones excluidas (establecida en compacTIA.asc):"

For i = 0 To numExtensiones - 1
    Print #reportFile, " - " & excluirExtensiones(i)
Next i
Print #reportFile, " - - - - - - - - - - - - - - - - - - - - - - - - - - - -"
Print #reportFile, " Cadena base excluida (establecida en compacTIA.asc):"
Print #reportFile, "  " & baseUrl
Print #reportFile, " "
Print #reportFile, " ======================================================="
Print #reportFile, " Lineas  totales procesadas: " & lineasLeidas
Print #reportFile, " NUmero de lineas excluidas: " & lineasExcluidas
Print #reportFile, " -------------------------------------------------------"
Print #reportFile, " Tamanyo indice-tesauro original: " & tamanyoOriginal & " KB"
Print #reportFile, " Nuevo Tamanyo tras compactaciOn: "
Print #reportFile, Chr(9) & " " & archivoSalida1 & ": " & tamanyoCompacto1 & " KB"
Print #reportFile, Chr(9) & archivoSalida2 & ": " & tamanyoCompacto2 & " KB"
Close #reportFile

Print "compacTIA toolkit: compactaciOn completada."
Print "Reporte generado en " & archivoReporte