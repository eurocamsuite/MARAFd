#lang "fb"

' local_SHA.bas
' Tecnología de Codigo Abierto MARAFd - Generador local de inventario SHA256
' Idea original: Rafael Lomena - MaRaF SOFT
' Autor código: Original por ChatGPT, modificado por Claude y autor                               
' https://calentamientoglobalacelerado.net/MARAFd/
'
' Compilado en FreeBASIC 1.8 (GCC) - Windows
'
' Estrategia:
'   - Usa CryptoAPI de Windows (advapi32.dll) para SHA-256
'   - Evita certutil por fichero (demasiado lento)
'   - Evita la implementacion SHA interna anterior, que fallo la autoprueba
'
' Entradas:
'   - indice-tesauro_compacto2.txt (opcional)
'
' Salidas:
'   - local_SHA.json
'   - local_SHA_report.txt
'
' Compilacion:
'   fbc64 local_SHA_v5.bas -s console -x local_SHA_v5.exe

Const OUTPUT_FILE        As String = "local_SHA.json"
Const REPORT_FILE        As String = "local_SHA_report.txt"
Const INDEX_FILE         As String = "indice-tesauro_compacto2.txt"
Const TEMP_FILELIST      As String = "__local_sha_filelist.tmp"
Const PROGRESS_EVERY     As Integer = 100
Const HASH_CHUNK_SIZE    As Integer = 65536
Const EXCLUDE_DEV_FILES  As Integer = 0

' ==== Windows CryptoAPI ====
Const PROV_RSA_AES         As UInteger = 24
Const CRYPT_VERIFYCONTEXT  As UInteger = &hF0000000u
Const CALG_SHA_256         As UInteger = &h0000800Cu
Const HP_HASHVAL           As UInteger = &h0002u

Declare Function CryptAcquireContextA Lib "advapi32.dll" Alias "CryptAcquireContextA" ( _
    ByRef phProv As Any Ptr, _
    ByVal pszContainer As ZString Ptr, _
    ByVal pszProvider As ZString Ptr, _
    ByVal dwProvType As UInteger, _
    ByVal dwFlags As UInteger) As Long

Declare Function CryptReleaseContext Lib "advapi32.dll" Alias "CryptReleaseContext" ( _
    ByVal hProv As Any Ptr, _
    ByVal dwFlags As UInteger) As Long

Declare Function CryptCreateHash Lib "advapi32.dll" Alias "CryptCreateHash" ( _
    ByVal hProv As Any Ptr, _
    ByVal Algid As UInteger, _
    ByVal hKey As Any Ptr, _
    ByVal dwFlags As UInteger, _
    ByRef phHash As Any Ptr) As Long

Declare Function CryptHashData Lib "advapi32.dll" Alias "CryptHashData" ( _
    ByVal hHash As Any Ptr, _
    ByVal pbData As Any Ptr, _
    ByVal dwDataLen As UInteger, _
    ByVal dwFlags As UInteger) As Long

Declare Function CryptGetHashParam Lib "advapi32.dll" Alias "CryptGetHashParam" ( _
    ByVal hHash As Any Ptr, _
    ByVal dwParam As UInteger, _
    ByVal pbData As Any Ptr, _
    ByRef pdwDataLen As UInteger, _
    ByVal dwFlags As UInteger) As Long

Declare Function CryptDestroyHash Lib "advapi32.dll" Alias "CryptDestroyHash" ( _
    ByVal hHash As Any Ptr) As Long

Function ReplaceAll(ByVal txt As String, ByVal findText As String, ByVal replText As String) As String
    Dim p As Integer
    Dim outText As String
    Dim restText As String

    If Len(findText) = 0 Then
        ReplaceAll = txt
        Exit Function
    End If

    restText = txt
    outText = ""

    Do
        p = InStr(restText, findText)
        If p = 0 Then
            outText = outText & restText
            Exit Do
        End If

        outText = outText & Left(restText, p - 1) & replText
        restText = Mid(restText, p + Len(findText))
    Loop

    ReplaceAll = outText
End Function

Function NormalizePath(ByVal s As String) As String
    Dim t As String
    t = Trim(s)
    t = ReplaceAll(t, "\", "/")

    Do While InStr(t, "//") > 0
        t = ReplaceAll(t, "//", "/")
    Loop

    Do While Len(t) > 0 And Left(t, 1) = "/"
        t = Mid(t, 2)
    Loop

    NormalizePath = t
End Function

Function RemoveUTF8BOM(ByVal s As String) As String
    If Len(s) >= 3 Then
        If Asc(Mid(s, 1, 1)) = &HEF And Asc(Mid(s, 2, 1)) = &HBB And Asc(Mid(s, 3, 1)) = &HBF Then
            RemoveUTF8BOM = Mid(s, 4)
            Exit Function
        End If
    End If
    RemoveUTF8BOM = s
End Function

Function NormalizeSHA(ByVal s As String) As String
    Dim t As String
    t = LCase(Trim(s))
    t = ReplaceAll(t, Chr(13), "")
    t = ReplaceAll(t, Chr(10), "")
    t = ReplaceAll(t, Chr(9), "")
    t = ReplaceAll(t, " ", "")
    t = ReplaceAll(t, Chr(34), "")
    t = ReplaceAll(t, ",", "")
    t = ReplaceAll(t, "}", "")
    t = ReplaceAll(t, "]", "")
    NormalizeSHA = t
End Function

Function IsHexLowerChar(ByVal c As String) As Integer
    If Len(c) <> 1 Then
        IsHexLowerChar = 0
        Exit Function
    End If

    If (c >= "0" And c <= "9") Or (c >= "a" And c <= "f") Then
        IsHexLowerChar = -1
    Else
        IsHexLowerChar = 0
    End If
End Function

Function IsValidSHA256(ByVal s As String) As Integer
    Dim t As String
    Dim i As Integer

    t = NormalizeSHA(s)
    If Len(t) <> 64 Then
        IsValidSHA256 = 0
        Exit Function
    End If

    For i = 1 To 64
        If IsHexLowerChar(Mid(t, i, 1)) = 0 Then
            IsValidSHA256 = 0
            Exit Function
        End If
    Next i

    IsValidSHA256 = -1
End Function

Function JsonEscape(ByVal s As String) As String
    Dim outText As String
    Dim i As Integer
    Dim ch As Integer
    Dim c As String

    outText = ""

    For i = 1 To Len(s)
        c = Mid(s, i, 1)
        ch = Asc(c)

        Select Case ch
        Case 34
            outText = outText & Chr(92) & Chr(34)
        Case 92
            outText = outText & "\\"
        Case 8
            outText = outText & "\b"
        Case 9
            outText = outText & "\t"
        Case 10
            outText = outText & "\n"
        Case 12
            outText = outText & "\f"
        Case 13
            outText = outText & "\r"
        Case 0 To 31
            outText = outText & "\u00" & Right("0" & Hex(ch), 2)
        Case Else
            outText = outText & c
        End Select
    Next i

    JsonEscape = outText
End Function

Function FileExistsLocal(ByVal pathName As String) As Integer
    Dim f As Integer
    f = FreeFile

    If Open(pathName For Input Access Read As #f) = 0 Then
        Close #f
        FileExistsLocal = -1
    Else
        FileExistsLocal = 0
    End If
End Function

Function IsLikelyHeaderLine(ByVal s As String) As Integer
    Dim t As String

    t = Trim(RemoveUTF8BOM(s))

    If t = "" Then
        IsLikelyHeaderLine = -1
        Exit Function
    End If

    If InStr(t, "/") = 0 And InStr(t, "\") = 0 And InStr(t, ".") = 0 Then
        If Len(t) <= 16 Then
            IsLikelyHeaderLine = -1
            Exit Function
        End If
    End If

    IsLikelyHeaderLine = 0
End Function

Function ShouldExcludeRelPath(ByVal relPath As String) As Integer
    Dim nameOnly As String
    Dim ext As String
    Dim p As Integer

    nameOnly = relPath
    p = InStrRev(nameOnly, "/")
    If p > 0 Then nameOnly = Mid(nameOnly, p + 1)

    If LCase(nameOnly) = LCase(OUTPUT_FILE) Then
        ShouldExcludeRelPath = -1
        Exit Function
    End If

    If LCase(nameOnly) = LCase(REPORT_FILE) Then
        ShouldExcludeRelPath = -1
        Exit Function
    End If

    If LCase(nameOnly) = LCase(TEMP_FILELIST) Then
        ShouldExcludeRelPath = -1
        Exit Function
    End If

    If EXCLUDE_DEV_FILES <> 0 Then
        p = InStrRev(nameOnly, ".")
        If p > 0 Then
            ext = LCase(Mid(nameOnly, p + 1))
            Select Case ext
            Case "bas", "bi", "exe", "cmd", "bat"
                ShouldExcludeRelPath = -1
                Exit Function
            End Select
        End If
    End If

    ShouldExcludeRelPath = 0
End Function

Function GetRelativePath(ByVal rootPath As String, ByVal fullPath As String) As String
    Dim rootNorm As String
    Dim fullNorm As String

    rootNorm = NormalizePath(rootPath)
    fullNorm = NormalizePath(fullPath)

    If Right(rootNorm, 1) <> "/" Then rootNorm = rootNorm & "/"

    If LCase(Left(fullNorm, Len(rootNorm))) = LCase(rootNorm) Then
        GetRelativePath = Mid(fullNorm, Len(rootNorm) + 1)
    Else
        GetRelativePath = fullNorm
    End If
End Function

Sub WriteJsonHeader(ByVal hOut As Integer)
    Print #hOut, Chr(&HEF) & Chr(&HBB) & Chr(&HBF);
    Print #hOut, "["
End Sub

Sub WriteJsonFooter(ByVal hOut As Integer)
    Print #hOut, ""
    Print #hOut, "]"
End Sub

Sub WriteJsonRecord(ByVal hOut As Integer, ByVal relPath As String, ByVal sha256 As String, ByRef firstRecord As Integer)
    Dim safePath As String
    Dim safeSha As String
    Dim rec As String

    safePath = JsonEscape(relPath)
    safeSha = JsonEscape(LCase(sha256))

    rec = "  {" & Chr(34) & "ruta_relativa" & Chr(34) & ":" & Chr(34) & safePath & Chr(34) & "," & _
          Chr(34) & "sha256" & Chr(34) & ":" & Chr(34) & safeSha & Chr(34) & "}"

    If firstRecord <> 0 Then
        Print #hOut, rec
        firstRecord = 0
    Else
        Print #hOut, ","
        Print #hOut, rec
    End If
End Sub

Sub ReportLine(ByVal hRep As Integer, ByVal msg As String)
    Print #hRep, msg
End Sub

Sub ShowProgress(ByVal processed As ULongInt, ByVal missing As ULongInt, ByVal failed As ULongInt)
    Print "Procesados OK: "; processed; " | Ausentes: "; missing; " | Fallos hash: "; failed
End Sub

Function ByteToHex2(ByVal b As UByte) As String
    Dim h As String
    h = Hex(b)
    If Len(h) = 1 Then h = "0" & h
    ByteToHex2 = LCase(h)
End Function

Function SHA256_Data_CryptoAPI(ByVal pData As Any Ptr, ByVal dataLen As UInteger) As String
    Dim hProv As Any Ptr
    Dim hHash As Any Ptr
    Dim hashBytes(0 To 31) As UByte
    Dim cbHash As UInteger
    Dim i As Integer
    Dim outHex As String

    hProv = 0
    hHash = 0
    outHex = ""

    If CryptAcquireContextA(hProv, 0, 0, PROV_RSA_AES, CRYPT_VERIFYCONTEXT) = 0 Then
        SHA256_Data_CryptoAPI = ""
        Exit Function
    End If

    If CryptCreateHash(hProv, CALG_SHA_256, 0, 0, hHash) = 0 Then
        CryptReleaseContext hProv, 0
        SHA256_Data_CryptoAPI = ""
        Exit Function
    End If

    If dataLen > 0 Then
        If CryptHashData(hHash, pData, dataLen, 0) = 0 Then
            CryptDestroyHash hHash
            CryptReleaseContext hProv, 0
            SHA256_Data_CryptoAPI = ""
            Exit Function
        End If
    End If

    cbHash = 32
    If CryptGetHashParam(hHash, HP_HASHVAL, @hashBytes(0), cbHash, 0) = 0 Then
        CryptDestroyHash hHash
        CryptReleaseContext hProv, 0
        SHA256_Data_CryptoAPI = ""
        Exit Function
    End If

    For i = 0 To 31
        outHex = outHex & ByteToHex2(hashBytes(i))
    Next i

    CryptDestroyHash hHash
    CryptReleaseContext hProv, 0

    SHA256_Data_CryptoAPI = outHex
End Function

Function SHA256_String_CryptoAPI(ByVal txt As String) As String
    If Len(txt) = 0 Then
        SHA256_String_CryptoAPI = SHA256_Data_CryptoAPI(0, 0)
    Else
        SHA256_String_CryptoAPI = SHA256_Data_CryptoAPI(StrPtr(txt), Len(txt))
    End If
End Function

Function SHA256_File_CryptoAPI(ByVal relOrAbsPath As String) As String
    Dim fn As Integer
    Dim fileLen As LongInt
    Dim filePos As LongInt
    Dim chunkSize As Integer
    Dim s As String
    Dim hProv As Any Ptr
    Dim hHash As Any Ptr
    Dim hashBytes(0 To 31) As UByte
    Dim cbHash As UInteger
    Dim i As Integer
    Dim outHex As String
    Dim pathForOpen As String

    pathForOpen = ReplaceAll(relOrAbsPath, "/", "\")

    fn = FreeFile
    If Open(pathForOpen For Binary Access Read As #fn) <> 0 Then
        SHA256_File_CryptoAPI = ""
        Exit Function
    End If

    hProv = 0
    hHash = 0

    If CryptAcquireContextA(hProv, 0, 0, PROV_RSA_AES, CRYPT_VERIFYCONTEXT) = 0 Then
        Close #fn
        SHA256_File_CryptoAPI = ""
        Exit Function
    End If

    If CryptCreateHash(hProv, CALG_SHA_256, 0, 0, hHash) = 0 Then
        CryptReleaseContext hProv, 0
        Close #fn
        SHA256_File_CryptoAPI = ""
        Exit Function
    End If

    fileLen = Lof(fn)
    filePos = 1

    While filePos <= fileLen
        chunkSize = HASH_CHUNK_SIZE
        If filePos + chunkSize - 1 > fileLen Then
            chunkSize = fileLen - filePos + 1
        End If

        s = Space(chunkSize)
        Get #fn, filePos, s

        If chunkSize > 0 Then
            If CryptHashData(hHash, StrPtr(s), chunkSize, 0) = 0 Then
                CryptDestroyHash hHash
                CryptReleaseContext hProv, 0
                Close #fn
                SHA256_File_CryptoAPI = ""
                Exit Function
            End If
        End If

        filePos = filePos + chunkSize
    Wend

    cbHash = 32
    If CryptGetHashParam(hHash, HP_HASHVAL, @hashBytes(0), cbHash, 0) = 0 Then
        CryptDestroyHash hHash
        CryptReleaseContext hProv, 0
        Close #fn
        SHA256_File_CryptoAPI = ""
        Exit Function
    End If

    Close #fn

    outHex = ""
    For i = 0 To 31
        outHex = outHex & ByteToHex2(hashBytes(i))
    Next i

    CryptDestroyHash hHash
    CryptReleaseContext hProv, 0

    SHA256_File_CryptoAPI = outHex
End Function

Function SelfTestSHA256() As Integer
    Dim h1 As String
    Dim h2 As String

    h1 = SHA256_String_CryptoAPI("")
    h2 = SHA256_String_CryptoAPI("abc")

    If h1 <> "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855" Then
        SelfTestSHA256 = 0
        Exit Function
    End If

    If h2 <> "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad" Then
        SelfTestSHA256 = 0
        Exit Function
    End If

    SelfTestSHA256 = -1
End Function

Sub ProcessOneRelativePath(ByVal rootPath As String, ByVal relPathIn As String, ByVal hOut As Integer, ByVal hRep As Integer, _
                           ByRef firstRecord As Integer, ByRef totalOK As ULongInt, ByRef totalMissing As ULongInt, ByRef totalHashFail As ULongInt)
    Dim relPath As String
    Dim fullPath As String
    Dim sha As String

    relPath = NormalizePath(RemoveUTF8BOM(Trim(relPathIn)))

    If relPath = "" Then Exit Sub
    If ShouldExcludeRelPath(relPath) <> 0 Then Exit Sub

    fullPath = rootPath
    If Right(fullPath, 1) <> "\" And Right(fullPath, 1) <> "/" Then fullPath = fullPath & "\"
    fullPath = fullPath & ReplaceAll(relPath, "/", "\")

    If FileExistsLocal(fullPath) = 0 Then
        totalMissing = totalMissing + 1
        ReportLine hRep, "MISSING: " & relPath
        Exit Sub
    End If

    sha = SHA256_File_CryptoAPI(fullPath)
    If sha = "" Or IsValidSHA256(sha) = 0 Then
        totalHashFail = totalHashFail + 1
        ReportLine hRep, "HASH_ERROR: " & relPath
        Exit Sub
    End If

    WriteJsonRecord hOut, relPath, sha, firstRecord
    totalOK = totalOK + 1

    If (totalOK Mod PROGRESS_EVERY) = 0 Then
        ShowProgress totalOK, totalMissing, totalHashFail
    End If
End Sub

Sub ProcessFromIndex(ByVal rootPath As String, ByVal indexPath As String, ByVal hOut As Integer, ByVal hRep As Integer, _
                     ByRef firstRecord As Integer, ByRef totalOK As ULongInt, ByRef totalMissing As ULongInt, ByRef totalHashFail As ULongInt, _
                     ByRef totalIndexLines As ULongInt, ByRef skippedHeaders As ULongInt)
    Dim hIn As Integer
    Dim lineText As String

    hIn = FreeFile
    If Open(indexPath For Input Access Read As #hIn) <> 0 Then Exit Sub

    While Not Eof(hIn)
        Line Input #hIn, lineText
        totalIndexLines = totalIndexLines + 1
        lineText = RemoveUTF8BOM(lineText)

        If Trim(lineText) <> "" Then
            If IsLikelyHeaderLine(lineText) <> 0 Then
                skippedHeaders = skippedHeaders + 1
            Else
                ProcessOneRelativePath rootPath, lineText, hOut, hRep, firstRecord, totalOK, totalMissing, totalHashFail
            End If
        End If
    Wend

    Close #hIn
End Sub

Function BuildPhysicalList(ByVal rootPath As String) As Integer
    Dim cmd As String

    If FileExistsLocal(TEMP_FILELIST) <> 0 Then Kill TEMP_FILELIST

    cmd = "cmd /c dir /b /s /a-d " & Chr(34) & rootPath & Chr(34) & " > " & Chr(34) & TEMP_FILELIST & Chr(34)
    Shell cmd

    If FileExistsLocal(TEMP_FILELIST) <> 0 Then
        BuildPhysicalList = -1
    Else
        BuildPhysicalList = 0
    End If
End Function

Sub ProcessFromPhysicalList(ByVal rootPath As String, ByVal hOut As Integer, ByVal hRep As Integer, _
                            ByRef firstRecord As Integer, ByRef totalOK As ULongInt, ByRef totalMissing As ULongInt, ByRef totalHashFail As ULongInt)
    Dim hIn As Integer
    Dim lineText As String
    Dim relPath As String

    If BuildPhysicalList(rootPath) = 0 Then Exit Sub

    hIn = FreeFile
    If Open(TEMP_FILELIST For Input Access Read As #hIn) <> 0 Then Exit Sub

    While Not Eof(hIn)
        Line Input #hIn, lineText
        lineText = RemoveUTF8BOM(lineText)

        If Trim(lineText) <> "" Then
            relPath = GetRelativePath(rootPath, lineText)
            ProcessOneRelativePath rootPath, relPath, hOut, hRep, firstRecord, totalOK, totalMissing, totalHashFail
        End If
    Wend

    Close #hIn

    If FileExistsLocal(TEMP_FILELIST) <> 0 Then Kill TEMP_FILELIST
End Sub

Dim rootPath As String
Dim indexFullPath As String
Dim hOut As Integer
Dim hRep As Integer
Dim firstRecord As Integer
Dim totalOK As ULongInt
Dim totalMissing As ULongInt
Dim totalHashFail As ULongInt
Dim totalIndexLines As ULongInt
Dim skippedHeaders As ULongInt

rootPath = CurDir
firstRecord = 1
totalOK = 0
totalMissing = 0
totalHashFail = 0
totalIndexLines = 0
skippedHeaders = 0

Print "local_SHA_v5.bas - MARAFd / inventario SHA256 local"
Print "Directorio raiz: "; rootPath
Print ""

If SelfTestSHA256() = 0 Then
    Print "ERROR: la autoprueba SHA256 ha fallado. Se aborta."
    End 1
End If

hRep = FreeFile
If Open(REPORT_FILE For Output Access Write As #hRep) <> 0 Then
    Print "ERROR: no se puede crear "; REPORT_FILE
    End 1
End If

ReportLine hRep, "local_SHA_v5.bas - MARAFd"
ReportLine hRep, "Directorio raiz: " & rootPath
ReportLine hRep, "Salida JSON: " & OUTPUT_FILE
ReportLine hRep, "Reporte: " & REPORT_FILE
ReportLine hRep, "SHA256: Windows CryptoAPI AUTOTEST OK"
ReportLine hRep, String(70, 45)

hOut = FreeFile
If Open(OUTPUT_FILE For Output Access Write As #hOut) <> 0 Then
    Print "ERROR: no se puede crear "; OUTPUT_FILE
    Close #hRep
    End 1
End If

WriteJsonHeader hOut

indexFullPath = rootPath
If Right(indexFullPath, 1) <> "\" And Right(indexFullPath, 1) <> "/" Then indexFullPath = indexFullPath & "\"
indexFullPath = indexFullPath & INDEX_FILE

If FileExistsLocal(indexFullPath) <> 0 Then
    Print "Modo inventario: usando "; INDEX_FILE
    ReportLine hRep, "Modo inventario: indice maestro " & INDEX_FILE
    ProcessFromIndex rootPath, indexFullPath, hOut, hRep, firstRecord, totalOK, totalMissing, totalHashFail, totalIndexLines, skippedHeaders
    ReportLine hRep, "Lineas leidas indice: " & Str(totalIndexLines)
    ReportLine hRep, "Cabeceras saltadas: " & Str(skippedHeaders)
Else
    Print "Modo inventario: exploracion fisica"
    ReportLine hRep, "Modo inventario: exploracion fisica"
    ProcessFromPhysicalList rootPath, hOut, hRep, firstRecord, totalOK, totalMissing, totalHashFail
End If

WriteJsonFooter hOut
Close #hOut

If FileExistsLocal(TEMP_FILELIST) <> 0 Then Kill TEMP_FILELIST

ReportLine hRep, String(70, 45)
ReportLine hRep, "Objetos procesados OK: " & Str(totalOK)
ReportLine hRep, "Objetos ausentes: " & Str(totalMissing)
ReportLine hRep, "Fallos hash: " & Str(totalHashFail)
Close #hRep

Print ""
Print "Fichero generado : "; OUTPUT_FILE
Print "Reporte         : "; REPORT_FILE
Print "Objetos OK      : "; totalOK
Print "Objetos ausentes: "; totalMissing
Print "Fallos hash     : "; totalHashFail
Print "Proceso finalizado."
