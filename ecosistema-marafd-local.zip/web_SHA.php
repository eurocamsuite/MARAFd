<?php
/*
 * web_SHA.php
 * Tecnologia de Codigo Abierto MARAFd  - SHA256 remoto por lotes, conservador para hosting compartido
 * Idea original: Rafael Lomena - MaRaF SOFT
 * Autor código: Original por ChatGPT, modificado por Claude y autor                               
 * https://calentamientoglobalacelerado.net/MARAFd/
 *
 * Estrategia:
 *   - peticiones cortas
 *   - bloqueo con flock()
 *   - guardado de estado tras cada tanda
 *   - meta refresh para continuar
 *   - ensamblado final deduplicando por ruta_relativa
 */

ignore_user_abort(true);
@set_time_limit(0);
@ini_set('max_execution_time', '0');
@ini_set('output_buffering', 'off');
@ini_set('zlib.output_compression', '0');
@ini_set('implicit_flush', '1');

$ROOT             = str_replace('\\', '/', __DIR__);
$INDEX_FILE       = 'indice-tesauro_compacto2.txt';
$OUTPUT_FILE      = 'web_SHA.json';
$REPORT_FILE      = 'web_SHA_report.txt';
$STATE_FILE       = 'web_SHA_state.json';
$TEMP_JSONL_FILE  = 'web_SHA.tmp.jsonl';
$LOCK_FILE        = 'web_SHA.lock';

$BATCH_SIZE            = 10;    // más pequeño para CGI-FCGI
$MAX_REQUEST_SECONDS   = 2.5;   // muy conservador para slavar restricciones hosting
$AUTO_CONTINUE_SEC     = 3;
$STRICT_INDEX          = false;
$EXCLUDE_SELF          = true;
$EXCLUDE_OUTPUTS       = true;

$selfName = basename(__FILE__);
$outPath   = $ROOT . '/' . $OUTPUT_FILE;
$repPath   = $ROOT . '/' . $REPORT_FILE;
$staPath   = $ROOT . '/' . $STATE_FILE;
$tmpPath   = $ROOT . '/' . $TEMP_JSONL_FILE;
$lockPath  = $ROOT . '/' . $LOCK_FILE;

function now_iso() {
    return date('Y-m-d H:i:s');
}

function h($s) {
    return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function report_append($msg) {
    global $repPath;
    @file_put_contents($repPath, $msg . PHP_EOL, FILE_APPEND);
}

function println($msg = '') {
    echo $msg . "<br>\n";
}

function normalize_rel_path($path) {
    $path = trim((string)$path);
    $path = str_replace('\\', '/', $path);
    while (strpos($path, '//') !== false) {
        $path = str_replace('//', '/', $path);
    }
    return ltrim($path, '/');
}

function safe_unlink($filePath) {
    if (is_file($filePath)) {
        @unlink($filePath);
    }
}

function is_likely_header_line($line) {
    $line = trim((string)$line);

    if ($line === '') {
        return true;
    }

    if (
        strpos($line, '/') === false &&
        strpos($line, '\\') === false &&
        strpos($line, '.') === false &&
        preg_match('/^[A-Za-z0-9_-]{1,16}$/', $line)
    ) {
        return true;
    }

    return false;
}

function should_exclude_rel($rel) {
    global $selfName, $OUTPUT_FILE, $REPORT_FILE, $STATE_FILE, $TEMP_JSONL_FILE, $LOCK_FILE;
    global $EXCLUDE_SELF, $EXCLUDE_OUTPUTS;

    $name = basename($rel);

    if ($EXCLUDE_SELF && $name === $selfName) {
        return true;
    }

    if ($EXCLUDE_OUTPUTS) {
        if (
            $name === $OUTPUT_FILE ||
            $name === $REPORT_FILE ||
            $name === $STATE_FILE ||
            $name === $TEMP_JSONL_FILE ||
            $name === $LOCK_FILE
        ) {
            return true;
        }
    }

    return false;
}

function load_paths_from_index($root, $indexFile, &$stats) {
    $indexPath = $root . '/' . $indexFile;
    $result = array();
    $seen = array();

    if (!is_file($indexPath)) {
        report_append('[' . now_iso() . '] ERROR: no existe ' . $indexFile);
        return $result;
    }

    $lines = @file($indexPath, FILE_IGNORE_NEW_LINES);
    if ($lines === false) {
        report_append('[' . now_iso() . '] ERROR: no se pudo leer ' . $indexFile);
        return $result;
    }

    foreach ($lines as $n => $lineRaw) {
        $line = trim((string)$lineRaw);

        if ($n === 0) {
            $line = preg_replace('/^\xEF\xBB\xBF/', '', $line);
        }

        if ($line === '') {
            $stats['empty_lines']++;
            continue;
        }

        if (is_likely_header_line($line)) {
            $stats['header_lines']++;
            continue;
        }

        $rel = normalize_rel_path($line);

        if ($rel === '') {
            $stats['empty_lines']++;
            continue;
        }

        if (should_exclude_rel($rel)) {
            $stats['excluded_lines']++;
            continue;
        }

        if (isset($seen[$rel])) {
            $stats['duplicate_lines']++;
            continue;
        }

        $seen[$rel] = true;
        $result[] = $rel;
    }

    return $result;
}

function save_state($data) {
    global $staPath;
    @file_put_contents(
        $staPath,
        json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
    );
}

function load_state() {
    global $staPath;
    if (!is_file($staPath)) {
        return null;
    }

    $raw = @file_get_contents($staPath);
    if ($raw === false || trim($raw) === '') {
        return null;
    }

    $data = json_decode($raw, true);
    if (!is_array($data)) {
        return null;
    }

    return $data;
}

function build_final_json_unique($tmpPath, $outPath, &$uniqueCount, &$duplicateCount, &$invalidCount) {
    $uniqueCount = 0;
    $duplicateCount = 0;
    $invalidCount = 0;

    $in = @fopen($tmpPath, 'rb');
    if ($in === false) {
        return false;
    }

    $map = array();

    while (($line = fgets($in)) !== false) {
        $line = trim($line);
        if ($line === '') {
            continue;
        }

        $row = json_decode($line, true);
        if (!is_array($row) || !isset($row['ruta_relativa']) || !isset($row['sha256'])) {
            $invalidCount++;
            continue;
        }

        $ruta = normalize_rel_path((string)$row['ruta_relativa']);
        $sha  = strtolower(trim((string)$row['sha256']));

        if ($ruta === '' || $sha === '') {
            $invalidCount++;
            continue;
        }

        if (isset($map[$ruta])) {
            $duplicateCount++;
        }

        $map[$ruta] = $sha;
    }

    fclose($in);

    ksort($map, SORT_STRING);
    $uniqueCount = count($map);

    $out = @fopen($outPath, 'wb');
    if ($out === false) {
        return false;
    }

    fwrite($out, "[\n");
    $first = true;

    foreach ($map as $ruta => $sha) {
        $rec = json_encode(
            array(
                'ruta_relativa' => $ruta,
                'sha256'        => $sha
            ),
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
        );

        if (!$first) {
            fwrite($out, ",\n");
        }

        fwrite($out, $rec);
        $first = false;
    }

    fwrite($out, "\n]\n");
    fclose($out);

    return true;
}

function reset_all() {
    global $repPath, $staPath, $tmpPath, $outPath, $lockPath;

    safe_unlink($repPath);
    safe_unlink($staPath);
    safe_unlink($tmpPath);
    safe_unlink($outPath);
    safe_unlink($lockPath);

    @file_put_contents($repPath, '');
    report_append('web_SHA_v5.php - Toolkit AUDITOR Id SHA256 - MARAFd technology');
    report_append('Fecha: ' . now_iso());
    report_append('Raiz: ' . str_replace('\\', '/', __DIR__));
    report_append('PHP_SAPI: ' . PHP_SAPI);
    report_append('PHP_VERSION: ' . PHP_VERSION);
    report_append('Inicializacion completa.');
}

header('Content-Type: text/html; charset=UTF-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Cache-Control: post-check=0, pre-check=0', false);
header('Pragma: no-cache');
header('Expires: 0');

if (isset($_GET['reset']) && $_GET['reset'] == '1') {
    reset_all();
}

$lockFP = @fopen($lockPath, 'c+');
if ($lockFP === false) {
    echo "<!DOCTYPE html><html lang='es'><head><meta charset='UTF-8'><title>web_SHA_v5 - error lock</title></head><body>";
    println('ERROR: no se pudo abrir el lock file.');
    echo "</body></html>";
    exit;
}

if (!@flock($lockFP, LOCK_EX | LOCK_NB)) {
    echo "<!DOCTYPE html><html lang='es'><head><meta charset='UTF-8'>";
    echo "<meta http-equiv='refresh' content='3;url=?run=1&t=" . rawurlencode((string)time()) . "'>";
    echo "<title>web_SHA_v5 - ocupado</title></head><body>";
    println('Otra petición ya está procesando un lote.');
    println('Se reintentará automáticamente en unos segundos.');
    echo "</body></html>";
    fclose($lockFP);
    exit;
}

set_error_handler(function($errno, $errstr, $errfile, $errline) {
    report_append('[' . now_iso() . '] PHP_WARNING errno=' . $errno . ' file=' . $errfile . ' line=' . $errline . ' msg=' . $errstr);
    return false;
});

register_shutdown_function(function() use ($lockFP) {
    $err = error_get_last();
    if ($err !== null) {
        report_append('[' . now_iso() . '] SHUTDOWN_LAST_ERROR type=' . $err['type'] . ' file=' . $err['file'] . ' line=' . $err['line'] . ' msg=' . $err['message']);
    }
    if (is_resource($lockFP)) {
        @flock($lockFP, LOCK_UN);
        @fclose($lockFP);
    }
});

$stats = array(
    'empty_lines'     => 0,
    'header_lines'    => 0,
    'excluded_lines'  => 0,
    'duplicate_lines' => 0
);

$state = load_state();
$paths = load_paths_from_index($ROOT, $INDEX_FILE, $stats);
$total = count($paths);

if ($state === null) {
    if (!is_file($repPath)) {
        reset_all();
    }

    $state = array(
        'created_at'         => now_iso(),
        'updated_at'         => now_iso(),
        'offset'             => 0,
        'total'              => $total,
        'done'               => false,
        'paths_file'         => $INDEX_FILE,
        'processed_ok'       => 0,
        'missing_total'      => 0,
        'hash_errors_total'  => 0,
        'requests_total'     => 0,
        'last_rate'          => 0
    );

    save_state($state);
    report_append('[' . now_iso() . '] INFO: cargando inventario desde ' . $INDEX_FILE);
    report_append('[' . now_iso() . '] INFO: candidatos=' . $total);
} else {
    $state['total'] = $total;
}

$state['requests_total'] = intval($state['requests_total']) + 1;

$requestStart = microtime(true);
$initialOffset = isset($state['offset']) ? intval($state['offset']) : 0;
if ($initialOffset < 0) $initialOffset = 0;
if ($initialOffset > $total) $initialOffset = $total;

$globalProcessedThisRequest = 0;
$globalMissingThisRequest = 0;
$globalHashErrorsThisRequest = 0;
$completedNow = false;

while (true) {
    $offset = isset($state['offset']) ? intval($state['offset']) : 0;
    if ($offset < 0) $offset = 0;
    if ($offset > $total) $offset = $total;

    $remaining = $total - $offset;
    if ($remaining <= 0) {
        break;
    }

    $elapsedRequest = microtime(true) - $requestStart;
    if ($elapsedRequest >= $MAX_REQUEST_SECONDS) {
        break;
    }

    $take = ($remaining > $BATCH_SIZE) ? $BATCH_SIZE : $remaining;

    $tmp = @fopen($tmpPath, 'ab');
    if ($tmp === false) {
        report_append('[' . now_iso() . '] ERROR: no se pudo abrir ' . $TEMP_JSONL_FILE . ' para anexado.');
        break;
    }

    $processedThisBatch = 0;
    $missingThisBatch = 0;
    $hashErrorThisBatch = 0;
    $batchStart = microtime(true);

    for ($i = $offset; $i < ($offset + $take); $i++) {
        if (!isset($paths[$i])) {
            break;
        }

        $rel = normalize_rel_path($paths[$i]);
        if ($rel === '') {
            continue;
        }

        $abs = $ROOT . '/' . $rel;

        if (!is_file($abs)) {
            $missingThisBatch++;
            report_append('[' . now_iso() . '] MISSING: ' . $rel);

            if ($STRICT_INDEX) {
                fclose($tmp);
                report_append('[' . now_iso() . '] ABORT: STRICT_INDEX activo.');
                break 2;
            }
            continue;
        }

        $sha = @hash_file('sha256', $abs);
        if ($sha === false) {
            $hashErrorThisBatch++;
            report_append('[' . now_iso() . '] HASH_ERROR: ' . $rel);
            continue;
        }

        $rec = json_encode(
            array(
                'ruta_relativa' => $rel,
                'sha256'        => $sha
            ),
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
        );

        @fwrite($tmp, $rec . PHP_EOL);
        $processedThisBatch++;
    }

    fclose($tmp);

    $offset += $take;
    $state['offset']            = $offset;
    $state['updated_at']        = now_iso();
    $state['processed_ok']      = intval($state['processed_ok']) + $processedThisBatch;
    $state['missing_total']     = intval($state['missing_total']) + $missingThisBatch;
    $state['hash_errors_total'] = intval($state['hash_errors_total']) + $hashErrorThisBatch;

    $elapsedBatch = microtime(true) - $batchStart;
    $rate = ($elapsedBatch > 0.0) ? ($processedThisBatch / $elapsedBatch) : 0.0;
    $state['last_rate'] = $rate;

    save_state($state);

    report_append(
        '[' . now_iso() . '] BATCH: offset=' . $offset . '/' . $total .
        ' ok=' . $processedThisBatch .
        ' missing=' . $missingThisBatch .
        ' hash_errors=' . $hashErrorThisBatch .
        ' rate=' . number_format($rate, 2, '.', '') . ' fich/s'
    );

    $globalProcessedThisRequest += $processedThisBatch;
    $globalMissingThisRequest += $missingThisBatch;
    $globalHashErrorsThisRequest += $hashErrorThisBatch;

    if ((microtime(true) - $requestStart) >= $MAX_REQUEST_SECONDS) {
        break;
    }
}

if (intval($state['offset']) >= $total && $total > 0) {
    $uniqueCount = 0;
    $duplicateCount = 0;
    $invalidCount = 0;
    $ok = build_final_json_unique($tmpPath, $outPath, $uniqueCount, $duplicateCount, $invalidCount);

    if ($ok) {
        $state['done'] = true;
        $state['updated_at'] = now_iso();
        save_state($state);

        report_append('[' . now_iso() . '] INFO: JSON final construido correctamente.');
        report_append('[' . now_iso() . '] INFO: registros_unicos=' . $uniqueCount . ' duplicados_tmp=' . $duplicateCount . ' invalidos_tmp=' . $invalidCount);
        $completedNow = true;
    } else {
        report_append('[' . now_iso() . '] ERROR: fallo al construir el JSON final.');
    }
}

$offset = isset($state['offset']) ? intval($state['offset']) : 0;
if ($offset < 0) $offset = 0;
if ($offset > $total) $offset = $total;

$remaining = $total - $offset;
$shouldContinue = (!$completedNow && empty($state['done']) && $remaining > 0);
$nextUrl = '?run=1&t=' . rawurlencode((string)time());

echo "<!DOCTYPE html><html lang='es'><head><meta charset='UTF-8'>";
if ($shouldContinue) {
    echo "<meta http-equiv='refresh' content='" . intval($AUTO_CONTINUE_SEC) . ";url=" . h($nextUrl) . "'>";
}
echo "<title>web_SHA_v5.php - Auditado masivo HASH - MARAFd technology</title>";
echo "<style>body{font-family:Consolas,Monaco,monospace;background:#fafafa;color:#333;padding:20px} .ok{color:#060} .warn{color:#b45f06} .err{color:#900}</style>";
echo "</head><body>";

println('web_SHA_v5.php - MARAFd technology');
println('Raíz: ' . h($ROOT));
println('PHP_SAPI: ' . h(PHP_SAPI));
println('Candidatos: ' . $total);
println('Offset inicial de esta petición: ' . $initialOffset);
println('Offset actual: ' . $offset);
println('Procesados en esta petición: ' . $globalProcessedThisRequest);
println('Faltantes en esta petición: ' . $globalMissingThisRequest);
println('Errores hash en esta petición: ' . $globalHashErrorsThisRequest);
println('Velocidad última tanda: ' . number_format(floatval($state['last_rate']), 2, '.', '') . ' fich/s');
println('Peticiones acumuladas: ' . intval($state['requests_total']));

if (!empty($state['done'])) {
    println('<span class="ok">Finalizado correctamente.</span>');
    println('JSON final: ' . h($OUTPUT_FILE));
    println('Reporte: ' . h($REPORT_FILE));
} else {
    $pct = ($total > 0) ? (($offset / $total) * 100.0) : 0.0;
    println('<span class="warn">Pendiente.</span>');
    println('Porcentaje: ' . number_format($pct, 2, '.', '') . '%');
    println('Siguiente URL: ' . h($nextUrl));
    echo "<p><a href='" . h($nextUrl) . "'>Continuar manualmente</a></p>";
}

echo "</body></html>";
?>