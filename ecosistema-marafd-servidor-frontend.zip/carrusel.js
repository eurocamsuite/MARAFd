// carrusel.js
document.addEventListener('DOMContentLoaded', async () => {

    // Variables globales
    let imagePaths = [];
    let currentIndex = 0;
    let autoInterval = null;
    const imageElement = document.getElementById('currentImage');
    const imageIndicator = document.getElementById('imageIndicator');
    const imageFileName = document.getElementById('imageFileName');
    const prevButton = document.getElementById('prevButton');
    const nextButton = document.getElementById('nextButton');
    const autoButton = document.getElementById('autoButton');
    const fullscreenButton = document.getElementById('fullscreenButton');
    const openButton = document.getElementById('openButton');
    const randomCheckbox = document.getElementById('randomCheckbox');
    // Nuevo elemento para número directo
    const imageNumberInput = document.getElementById('imageNumberInput');

    // Extensiones de archivo permitidas
    const allowedExtensions = ['.bmp', '.jpg', '.jpeg', '.gif', '.png'];

    // Extrae nombre de fichero de la ruta
    function getFileName(filePath) {
        return filePath.split('/').pop();
    }

    // Carga las carpetas a excluir desde carrusel_exc.dat
    async function loadExcludedFolders() {
        try {
            const response = await fetch('carrusel_exc.dat');
            if (!response.ok) {
                // Si el fichero no existe, no se excluye nada
                return [];
            }
            const text = await response.text();
            return text.split('\n')
                .map(line => line.trim())
                // Ignorar líneas vacías o comentarios
                .filter(line => line && !line.startsWith('//'))
                // Quitar las comillas
                .map(line => line.replace(/"/g, ''));
        } catch (error) {
            console.error('Error al cargar el archivo de exclusión carrusel_exc.dat:', error);
            // En caso de error, no excluir nada
            return [];
        }
    }

    // Carga el índice de imágenes
    async function loadImagePaths() {
        try {
            // Cargar primero la lista de carpetas excluidas
            const excludedFolders = await loadExcludedFolders();

            const response = await fetch('indice-tesauro.txt');
            const text = await response.text();
            imagePaths = text.split('\n')
                .map(path => path.trim())
                // Filtrar las rutas que contienen carpetas excluidas
                .filter(path => {
                    if (!path) return false;
                    // Devolver 'true' solo si la ruta NO contiene ninguna de las carpetas excluidas
                    return !excludedFolders.some(folder => path.startsWith(folder + '/') || path.includes('/' + folder + '/'));
                })
                // Mantener el filtro original de extensiones
                .filter(path => path && allowedExtensions.some(ext => path.toLowerCase().endsWith(ext)));

            if (imagePaths.length > 0) {
                // Mostrar siempre la primera al cargar
                imageElement.src = imagePaths[0];
                updateImageIndicator();
                // Fijar rango máximo del input
                imageNumberInput.max = imagePaths.length;
            } else {
                imageElement.alt = 'No se encontraron imágenes.';
                imageIndicator.textContent = '0 / 0';
                imageFileName.textContent = '-';
            }
        } catch (error) {
            console.error('Error al cargar el índice de imágenes:', error);
            imageElement.alt = 'Error al cargar las imágenes.';
            imageIndicator.textContent = '0 / 0';
            imageFileName.textContent = '-';
        }
    }

    // Actualiza la imagen mostrada (con salto aleatorio si está activo)
    function updateImage() {
        if (imagePaths.length > 0) {
            if (randomCheckbox.checked) {
                currentIndex = Math.floor(Math.random() * imagePaths.length);
            }
            imageElement.src = imagePaths[currentIndex];
            updateImageIndicator();
        }
    }

    // Actualiza indicador y nombre de fichero
    function updateImageIndicator() {
        imageIndicator.textContent = `${currentIndex + 1} / ${imagePaths.length}`;
        imageFileName.textContent = getFileName(imagePaths[currentIndex]);
    }

    // Botones navegación
    prevButton.addEventListener('click', () => {
        if (imagePaths.length > 0) {
            if (randomCheckbox.checked) {
                currentIndex = Math.floor(Math.random() * imagePaths.length);
            } else {
                currentIndex = (currentIndex - 1 + imagePaths.length) % imagePaths.length;
            }
            updateImage();
        }
    });
    nextButton.addEventListener('click', () => {
        if (imagePaths.length > 0) {
            if (randomCheckbox.checked) {
                currentIndex = Math.floor(Math.random() * imagePaths.length);
            } else {
                currentIndex = (currentIndex + 1) % imagePaths.length;
            }
            updateImage();
        }
    });

    // Carrusel automático
    autoButton.addEventListener('click', () => {
        if (autoInterval) {
            clearInterval(autoInterval);
            autoInterval = null;
            autoButton.textContent = 'Carrusel 10 sg.';
        } else {
            autoInterval = setInterval(() => {
                // avanza o aleatorio según checkbox
                if (randomCheckbox.checked) {
                    currentIndex = Math.floor(Math.random() * imagePaths.length);
                } else {
                    currentIndex = (currentIndex + 1) % imagePaths.length;
                }
                updateImage();
            }, 10000);
            autoButton.textContent = 'Detener Automático';
        }
    });

    // Pantalla completa
    fullscreenButton.addEventListener('click', () => {
        if (!document.fullscreenElement) {
            document.documentElement.requestFullscreen();
        } else {
            document.exitFullscreen();
        }
    });

    // Abrir imagen en nueva ventana
    openButton.addEventListener('click', () => {
        if (imagePaths.length > 0) {
            window.open(imagePaths[currentIndex], '_blank');
        }
    });

    // Evento ENTER en el input de número
    imageNumberInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            const num = parseInt(imageNumberInput.value, 10);
            if (!isNaN(num) && num >= 1 && num <= imagePaths.length) {
                currentIndex = num - 1;
                updateImage();
            }
        }
    });

    // Arrancar
    await loadImagePaths();
});