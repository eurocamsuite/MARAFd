﻿[EN ESPAÑOL] * * * * * * * * * * * * * * *

GENESIS DEL PROYECTO FONDO DOCUMENTAL DIGITAL 
---------------------------------------------
Fecha: OCT-2022 (LANZAMIENTO)
 TEMA: MELILLA, HISTORIA DE MELILLA Y LA REGION DEL RIF EN EL NORTE DE MARRUECOS
  WEB: https://calentamientoglobalacelerado.net/fondo_documental_Melilla_Riff/
ADMIN: RAFAEL LOMENA - eurocamsuite@yahoo.es
---------------------------------------------

   Tras la comprobación personal de la importante fragmentación que afecta a toda la documentación disponible en la Red y con una pretensión únicamente divulgativa y unificadora surge este humilde proyecto abierto de preservación documental digitalizada sobre la historia de la ciudad española de Melilla y la región del Rif en el norte de Marruecos destinado a curiosos e investigadores y que refunda contenido de gran valor recogido de multitud de fuentes y repositorios.

   No obstante, y pese a la firme finalidad y compromiso únicamente preservativo, divulgativo y/o académico del presente fondo documental, algunos de los documentos preservados en el mismo podrían estar sometidos a ciertas restricciones legales de uso establecidas por su/s respectivo/s autor/es y/o propietarios. 

   A este respecto, antes de hacer un uso exclusivamente investigativo de cualquier material albergado en este fondo usted deberá verificar las restricciones de uso que en su caso pudieran afectar a dichos contenidos. En cualquier caso, lea antes el presente archivo sobre las bases del fondo.

NOTA PARA COLABORADORES Y CONTRIBUCIONES
----------------------------------------
   Al tratarse de un proyecto abierto y libre, cualquier persona que lo desee puede colaborar aportando contenidos digitales al fondo, siempre y cuando no se considere que pudieran atentar contra la libertad y/o derechos de terceros, reservándose el administrador el derecho de decisión en este sentido. Tanto para aportaciones* al fondo como para posibles sugerencias, críticas o cualquier otro tipo de contacto con el administrador del mismo deberá dirigirse a la cuenta de correos:

   eurocamsuite@yahoo.es 
   info@calentamientoglobalacelerado.net

   *Las aportaciones digitales al fondo documental deberán comunicarse previamente al administrador del mismo al objeto de mejorar y facilitar el envío de archivos mediante correo electrónico, por ello, NO ENVÍE DIRECTAMENTE NINGÚN FICHERO ADJUNTO A LA CUENTA DE CORREOS DEL ADMINISTRADOR sin haber contactado antes con éste mediante un mensaje simple de email (SIN ARCHIVO ADJUNTO)


NOTA PARA USUARIOS, ESTUDIANTES Y/O INVESTIGADORES
--------------------------------------------------
   Aun pendiente de clasificación en una gran parte de su contenido, todo el volumen documental actualmente disponible se encuentra ya a disposición de cualquier usuario que desee descargar o consultar.


NOTA PARA AUTORES DE CONTENIDOS Y OBRAS
---------------------------------------	
   Dado el considerable volumen documental tratado, así como las dificultades enfrentadas para la puesta en marcha de este proyecto (desarrollado por una única persona) se han revisado y recopilado obras de infinidad de fuentes y autores durante años, fotografías y documentos en su mayor parte, por lo que sería posible que alguna de las obras aquí recopiladas pudiera estar protegida por algún tipo de restricción tales como licencias Creative Commons u otro tipo de regulaciones en lo que a derechos de autor se refiere. En este sentido, y dado el marcado carácter altruísta del presente trabajo, cualquier autor que lo considere puede ejercer plenamente su derecho sobre la/s misma/s exponiendo el criterio y argumentación para su retirada del fondo al administrador del mismo en cualquiera de las cuentas de correos:

   eurocamsuite@yahoo.es
   info@calentamientoglobalacelerado.net



[IN ENGLISH]  * * * * * * * * * * * * * * * * *

GENESIS OF THE DIGITAL DOCUMENTARY FUND PROJECT
-----------------------------------------------
 Date: OCT-2022 (LAUNCH)
TOPIC: MELILLA, HISTORY OF MELILLA AND THE RIF REGION IN NORTHERN MOROCCO
  WEB: https://calentamientoglobalacelerado.net/fondo_documental_Melilla_Riff/
ADMIN: RAFAEL LOMENA - eurocamsuite@yahoo.es
-----------------------------------------------

   After personal verification of the important fragmentation that affects all the documentation available on the Internet and with a solely informative and unifying aim, this humble open project of digitized documentary preservation arises on the history of the Spanish city of Melilla and the Rif region in the north of Morocco for the curious and researchers and that recasts content of great value collected from a multitude of sources and repositories.

   However, and despite the firm purpose and commitment solely to preservation, informative and/or academic purposes of this documentary collection, some of the documents preserved therein could be subject to certain legal restrictions of use established by their respective document(s). author(s) and/or owners.

  In this regard, before making exclusively investigative use of any material hosted in this fund, you must verify the use restrictions that, if applicable, could affect said content. In any case, read this file first about the basics of the fund.

NOTE FOR COLLABORATORS AND CONTRIBUTIONS
----------------------------------------
   As it is an open and free project, anyone who wishes can collaborate by contributing digital content to the fund, as long as it is not considered that they could violate the freedom and/or rights of third parties, the administrator reserving the right of decision in this sense. Both for contributions* to the fund and for possible suggestions, criticism or any other type of contact with its administrator, you should go to the email account:

   eurocamsuite@yahoo.es
   info@calentamientoglobalacelerado.net

   *The digital contributions to the documentary collection must be previously communicated to the administrator of the same in order to improve and facilitate the sending of files by email, therefore, DO NOT SEND ANY FILE ATTACHED DIRECTLY TO THE ADMINISTRATOR'S MAIL ACCOUNT without first contacting him through a simple email message (NO FILE ATTACHED)


NOTE FOR USERS, STUDENTS AND/OR RESEARCHERS
-------------------------------------------
   A large part of its content is still pending classification, the entire documentary volume currently available is already available to any user who wishes to download or consult it.


NOTE FOR AUTHORS OF CONTENT AND WORKS
-------------------------------------
   Given the considerable documentary volume dealt with, as well as the difficulties faced in starting this project (developed by a single person), works from countless sources and authors have been reviewed and compiled over the years, photographs and documents for the most part, for what would be possible that some of the works compiled here could be protected by some type of restriction such as Creative Commons licenses or other types of regulations as far as copyright is concerned. In this sense, and given the markedly altruistic nature of this work, any author who considers it may fully exercise his/her right over it/them(s) exposing the criteria and arguments for their withdrawal from the fund to the administrator of the same in any of the accounts. of mails:

   eurocamsuite@yahoo.es
   info@calentamientoglobalacelerado.net



[EN FRANÇAIS]  * * * * * * * * * * * * * * * * *

GENÈSE DU PROJET FONDS DU DOCUMENTAIRE NUMÉRIQUE
------------------------------------------------
 Date: octobre 2022 (LANCEMENT)
THÈME: MELILLA, HISTOIRE DE MELILLA ET DE LA RÉGION DU RIF AU NORD DU MAROC
  WEB: https://calentamientoglobalacelerado.net/fondo_documental_Melilla_Riff/
ADMIN: RAFAEL LOMENA - eurocamsuite@yahoo.es
------------------------------------------------

   Après vérification personnelle de l'importante fragmentation qui affecte toute la documentation disponible sur Internet et dans un but uniquement informatif et fédérateur, cet humble projet ouvert de conservation documentaire numérisée se pose sur l'histoire de la ville espagnole de Melilla et de la région du Rif au nord du Maroc pour les curieux et les chercheurs et qui refond des contenus de grande valeur collectés à partir d'une multitude de sources et de référentiels.

   Cependant, et malgré la ferme intention et l'engagement uniquement à des fins de préservation, d'information et/ou académiques de cette collection documentaire, certains des documents qui y sont conservés pourraient être soumis à certaines restrictions légales d'utilisation établies par leur(s) auteur(s) respectif(s). (s) et/ou propriétaires.

   À cet égard, avant d'utiliser exclusivement à des fins d'investigation tout matériel hébergé dans ce fonds, vous devez vérifier les restrictions d'utilisation qui, le cas échéant, pourraient affecter ledit contenu. Dans tous les cas, lisez d’abord ce dossier sur les bases du fonds.

NOTE POUR LES COLLABORATEURS ET CONTRIBUTIONS
---------------------------------------------
   S'agissant d'un projet ouvert et gratuit, toute personne qui le souhaite peut collaborer en apportant du contenu numérique au fonds, tant qu'il n'est pas considéré qu'il pourrait violer la liberté et/ou les droits de tiers, l'administrateur se réservant le droit de décision. Tant pour les contributions* au fonds que pour d'éventuelles suggestions, critiques ou tout autre type de contact avec son administrateur, vous devez vous rendre sur le compte de messagerie :

   eurocamsuite@yahoo.es
   info@calentamientoglobalacelerado.net

   *Les contributions numériques à la collection documentaire doivent être préalablement communiquées à l'administrateur de celle-ci afin d'améliorer et de faciliter l'envoi de fichiers par e-mail, par conséquent, N'ENVOYEZ AUCUN FICHIER JOINT DIRECTEMENT AU COMPTE DE COURRIER DE L'ADMINISTRATEUR sans l'avoir préalablement contacté via un message électronique simple (AUCUN FICHIER JOINT)


NOTE POUR LES UTILISATEURS, ÉTUDIANTS ET/OU CHERCHEURS
------------------------------------------------------
   Une grande partie de son contenu est encore en attente de classement, l'intégralité du volume documentaire actuellement disponible est déjà accessible à tout utilisateur qui souhaite le télécharger ou le consulter.


NOTE AUX AUTEURS DE CONTENU ET D'ŒUVRES
---------------------------------------
   Compte tenu du volume documentaire considérable traité, ainsi que des difficultés rencontrées pour démarrer ce projet (élaboré par une seule personne), des œuvres d'innombrables sources et auteurs ont été examinées et compilées au fil des ans, photographies et documents pour la plupart, pour ce qui serait possible que certaines des œuvres compilées ici soient protégées par un certain type de restriction telles que les licences Creative Commons ou d'autres types de réglementations en matière de droit d'auteur. En ce sens, et compte tenu du caractère nettement altruiste de cette œuvre, tout auteur qui la considère peut exercer pleinement son droit sur celle-ci en exposant les critères et arguments de son retrait du fonds à l'administrateur de la même dans l'un des comptes. de mails :

   eurocamsuite@yahoo.es
   info@calentamientoglobalacelerado.net

