﻿<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BUSQUEDA RAPIDA MARAFd [OpenSource] en Fondo Documental Digital Melilla - Riff</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 10px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 15px;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }

        .header {
            background: linear-gradient(135deg, #4CAF50 0%, #2E7D32 100%);
            color: white;
            padding: 20px;
            text-align: center;
            border-radius: 12px;
            margin-bottom: 20px;
            box-shadow: 0 5px 20px rgba(76, 175, 80, 0.3);
        }

        .header img {
            width: 100%;
            max-width: 825px;
            height: auto;
            border-radius: 8px;
            transition: transform 0.3s ease;
        }

        .header img:hover {
            transform: scale(1.02);
        }

        .search-section {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            padding: 25px;
            border-radius: 12px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
        }

        .search-section h1 {
            color: #2c3e50;
            margin-bottom: 15px;
            font-size: clamp(1.5rem, 4vw, 2.2rem);
            font-weight: 700;
            text-align: center;
            background: linear-gradient(135deg, #667eea, #764ba2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .search-section h3 {
            color: #34495e;
            margin-bottom: 12px;
            font-size: clamp(0.9rem, 2.5vw, 1.1rem);
            line-height: 1.5;
            background: rgba(255, 255, 255, 0.7);
            padding: 12px;
            border-radius: 8px;
            border-left: 4px solid #3498db;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.05);
        }

        .search-section h3::before {
            content: '💡';
            margin-right: 8px;
        }

        form {
            text-align: center;
            margin: 20px 0;
            padding: 20px;
            background: rgba(255, 255, 255, 0.9);
            border-radius: 12px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 15px;
            align-items: center;
        }

        form input[type="text"] {
            padding: 12px 18px;
            font-size: 16px;
            border: 2px solid #e0e0e0;
            border-radius: 25px;
            width: 100%;
            max-width: 400px;
            outline: none;
            transition: all 0.3s ease;
            background: white;
            box-shadow: inset 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        form input[type="text"]:focus {
            border-color: #4CAF50;
            box-shadow: 0 0 15px rgba(76, 175, 80, 0.3);
        }

        form input[type="submit"] {
            padding: 12px 25px;
            font-size: 16px;
            background: linear-gradient(135deg, #4CAF50 0%, #45a049 100%);
            color: white;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 12px rgba(76, 175, 80, 0.3);
            font-weight: 600;
            min-width: 120px;
        }

        form input[type="submit"]:hover {
            background: linear-gradient(135deg, #45a049 0%, #4CAF50 100%);
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(76, 175, 80, 0.4);
        }

        .results {
            background: white;
            border-radius: 12px;
            padding: 15px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .results p {
            padding: 12px;
            margin: 4px 0;
            border-radius: 8px;
            border-left: 4px solid #4CAF50;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        .results a {
            color: #2980b9;
            text-decoration: none;
            font-weight: 500;
            word-wrap: break-word;
        }

        .results a:hover {
            color: #3498db;
        }

        .results hr {
            border: none;
            height: 2px;
            background: linear-gradient(90deg, transparent, #4CAF50, transparent);
            margin: 15px 0;
        }

        .results .separator-line {
            display: none;
        }

        .search-stats {
            background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
            color: white;
            padding: 15px;
            border-radius: 10px;
            text-align: center;
            margin: 15px 0;
            box-shadow: 0 5px 15px rgba(44, 62, 80, 0.3);
        }

        .search-stats h2 {
            margin: 8px 0;
            font-size: clamp(1.1rem, 3vw, 1.5rem);
        }

        .no-results {
            background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
            color: white;
            padding: 20px;
            border-radius: 12px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(231, 76, 60, 0.3);
        }

        .donation {
            background: linear-gradient(135deg, #f39c12 0%, #e67e22 100%);
            color: white;
            padding: 20px;
            border-radius: 12px;
            text-align: center;
            margin: 20px 0;
            box-shadow: 0 5px 20px rgba(243, 156, 18, 0.3);
        }

        .donation p {
            line-height: 1.5;
            margin-bottom: 15px;
            font-size: clamp(0.9rem, 2.5vw, 1rem);
        }

        .donation form {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            padding: 15px;
        }

        .donation input[type="image"] {
            transition: transform 0.3s ease;
            border-radius: 8px;
            max-width: 100%;
            height: auto;
        }

        .donation input[type="image"]:hover {
            transform: scale(1.05);
        }

        .footer {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            color: #2c3e50;
            padding: 20px;
            border-radius: 12px;
            text-align: center;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        }

        .footer p {
            margin: 8px 0;
            line-height: 1.5;
            font-size: clamp(0.9rem, 2.5vw, 1rem);
        }

        .footer a {
            color: #2980b9;
            text-decoration: none;
            word-wrap: break-word;
        }

        .footer a:hover {
            color: #3498db;
        }

        .footer img {
            margin: 10px 0;
            max-width: 100%;
            height: auto;
            transition: transform 0.3s ease;
        }

        .footer img:hover {
            transform: scale(1.05);
        }

        .tick-icon {
            color: #4CAF50;
            margin-right: 8px;
            font-size: 14px;
            flex-shrink: 0;
        }

        .folder-badge {
            background: linear-gradient(135deg, #27ae60 0%, #2ecc71 100%);
            color: white;
            padding: 2px 6px;
            border-radius: 12px;
            font-size: 0.75em;
            font-weight: 600;
            margin-left: 8px;
            white-space: nowrap;
        }

        .result-item {
            display: flex;
            align-items: flex-start;
            gap: 8px;
        }

        .result-content {
            flex: 1;
            min-width: 0;
        }

        /* Optimizaciones para móviles */
        @media (max-width: 768px) {
            body {
                padding: 5px;
            }
            
            .container {
                padding: 10px;
                border-radius: 10px;
            }
            
            .header {
                padding: 15px;
            }
            
            .search-section {
                padding: 15px;
            }
            
            .form-group {
                width: 100%;
            }
            
            form {
                padding: 15px;
            }
            
            form input[type="text"] {
                width: 100%;
                margin-bottom: 0;
            }
            
            .results {
                padding: 10px;
            }
            
            .results p {
                padding: 8px;
                font-size: 14px;
            }
            
            .donation {
                padding: 15px;
            }
            
            .footer {
                padding: 15px;
            }
        }

        @media (max-width: 480px) {
            .container {
                margin: 2px;
                padding: 8px;
            }
            
            .header {
                padding: 10px;
            }
            
            .search-section {
                padding: 12px;
            }
            
            .search-section h3 {
                padding: 8px;
                font-size: 0.85rem;
            }
            
            form {
                padding: 10px;
            }
            
            .results p {
                padding: 6px;
                font-size: 13px;
            }
            
            .donation p {
                font-size: 0.85rem;
            }
            
            .footer p {
                font-size: 0.85rem;
            }
        }

        /* Eliminamos animaciones pesadas en móviles */
        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after {
                animation-duration: 0.01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: 0.01ms !important;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <a href="https://calentamientoglobalacelerado.net/fondo_documental_Melilla_Riff/">
            <img src="img/cabecera_fondo_documental_melilla_riff.jpg" alt="FONDO DOCUMENTAL SOBRE CIUDAD DE MELILLA Y LA REGION DEL RIF EN EL NORTE DE MARRUECOS">
        </a>
    </div>

    <div class="search-section">
        <h1><b><u>BUSQUEDA RAPIDA FONDO MELILLA-RIF</u></b></h1>
        <h3>MAXIMO TRES palabras por consulta. EJEMPLOS: <br>MELILLA VIEJA; BRAVO NIETO; 1970; AKROS; PICASO; AMAZIG; MAPA MARR JPG; BEREBER; DICCIO; ...</h3>
        <h3>EVITE SIEMPRE el uso de preposiciones, art&iacute;culos u 
        otros conectores lingu&iacute;sticos (EL, LAS, PARA, DESDE, etc.) as&iacute; 
        como el uso de tildes y/o s&iacute;mbolos ...</h3>
        <h3>Puede recurrir al uso de ABREVIATURAS para agilizar algunos
         rastreos: <br>TFG (trabajo fin de grado); TD (tesis doctoral); 1980; ...</h3>
        <h3>Para hacer b&uacute;squedas en el INTERIOR DE VARIOS DOCUMENTOS 
        consulte con el administrador en <br>eurocamsuite[arroba]yahoo.es ó 
        utilice la opción de BUSQUEDA CON TECNOLOGIA GOOGLE accesible desde la web principal del fondo</h3>

        <form action="" method="post">
            <div class="form-group">
                <input type="text" name="search" size="40" placeholder="ej ANUAL (3 palab./word MAXIMO)">
                <input type="submit" name="submit" value="🔍 Buscar">
            </div>
        </form>
    </div>

    <div class="results">
<?php
// PROYECTO: MARAFd - GESTION INTELIGENTE DE FONDOS DOCUMENTALES DIGITALES BASADA EN TESAURO                     
// Ecosistema tecnologia: MARAFd (c)(c) 2026
// Proceso en servidor: finder3.php by MARAFd - TECNOLOGIA PARA LA GESTION DE FONDOS DOCUMENTALES DIGITALES
// Creative Commons Attribution-NonCommercial-ShareAlike 4.0 - 06/02/2025 - Num.reg. 2502060809787          
// OPEN SOURCE SOLUTION by RAFAEL LOMENA VARO - MARAF SOFT 1993 ©© 2026    
// Idea original: Rafael Lomena - MaRaF SOFT
// Autor código: Original por ChatGPT, modificado por Claude y autor                                
// https://calentamientoglobalacelerado.net/MARAFd/
//
// Program: finder3.php 
// PHP version: 8.3
// Fecha: 30/04/2025 - revision 14/03/2026     
// Autor: Original por ChatGPT, modificado por Gemini, Claude y autor idea 
// Idea original: Rafael Lomena - MaRaF SOFT
// Ecosistema tecnologia: MARAFd (c)(c) 2026                                
// Descripcion: sistema de búsqueda rápida fonética en indice-tesauro y generacion de enlaces dinamicos

// FLUJO DEL PROCESO:
// Se lee entrada de maximo 3 cadenas de texto y se noramlizan los caraceteres para lanzar busqueda en archivo 
//    inidice-tesauro alojado en servidor
//    Se crea reporte HTML con resultados e hiperenlaces directo a documentos
function normalize($string) {
    $normalized = Normalizer::normalize($string, Normalizer::FORM_D);
    $normalized = preg_replace('/\p{Mn}/u', '', $normalized);
    $normalized = str_replace(['Ń', 'ń'], ['N', 'n'], $normalized);

    // Antes de eliminar caracteres no alfanuméricos, tratar guiones y guiones bajos como separadores.
    // Se sustituyen por espacios para que no se unan palabras contiguas, evitando que 'll' se forme
    // artificialmente al eliminar el separador. Esto permite que 'Rafael-Lomena' o 'Rafael_Lomena' se
    // normalicen como 'rafael lomena' y no como 'rafaellomena', lo que impedía encontrar coincidencias
    // correctamente.  
    $normalized = str_replace(['-', '_'], ' ', $normalized);
    
    // Convertir a minúsculas y eliminar caracteres no alfanuméricos (excepto espacios)
    $normalized = mb_strtolower($normalized);
    $normalized = preg_replace('/[^a-z0-9\s]/', '', $normalized);
    
    // Equivalencia LL → Y (primero para evitar conflictos)
    $normalized = str_replace('ll', 'y', $normalized); // Paso clave
    
    // Equivalencias del fonema /k/: Q/QU y C delante de A, O, U -> K.
    // Ejemplos: estocolmo/estokolmo -> estokolmo; casa/kasa -> kasa; cuba/kuba -> kuba.
    // No se elimina la 'u' de 'ku': 'ku' representa /ku/ y debe conservarse.
    $normalized = str_replace(['qu', 'q'], 'k', $normalized);
    $normalized = preg_replace('/c([aou])/i', 'k$1', $normalized);
    
    // Reducir letras consecutivas duplicadas
    $normalized = preg_replace('/(.)\1+/u', '$1', $normalized);
    
    // Equivalencias fonéticas existentes
    $normalized = str_replace(
        ['v', 'á', 'é', 'í', 'ó', 'ú', 'j', 'h', 'y'],
        ['b', 'a', 'e', 'i', 'o', 'u', 'g', '', 'y'], 
        $normalized
    );
    
    $normalized = preg_replace(
        ['/c([ei])/i', '/z/i', '/g([ei])/i'], 
        ['s$1', 's', 'j$1'], 
        $normalized
    );
    
    return $normalized;
}
if (isset($_POST['submit'])) {
    $search_string = $_POST['search'];
    $normalized_search_string = normalize($search_string);
    $search_words = mb_split('\s+', $normalized_search_string);
    // Modificación para manejar palabras en plural
    $search_words = array_map(function($word) {
        // Solo procesar palabras con más de 4 caracteres que terminen en 's'
        if (mb_strlen($word) > 4 && mb_substr($word, -1) === 's') {
            return mb_substr($word, 0, -1);
        }
        return $word;
    }, $search_words);
    
    $search_words = array_slice($search_words, 0, 3);
 
    $file = "index_fondo_Melilla_Rif.asc";
    $file_contents = file_get_contents($file);
    $lines = explode("\n", $file_contents);
    $bg_color = false;
    $count = 0;
    $total_count = 0;
 
    echo "<hr style='border: none; height: 2px; background: linear-gradient(90deg, transparent, #4CAF50, transparent); margin: 20px 0;' />";
 
    foreach ($lines as $line) {
        $line = trim($line);
        if (preg_match('/\.\w+$/', $line)) {
            $total_count++;
        }
        $normalized_line = normalize($line);
        $found_words = 0;
        foreach ($search_words as $word) {
            if (strpos($normalized_line, $word) !== false) {
                $found_words++;
            }
        }
 
		if ($found_words == count($search_words)) {
			if (preg_match('/\.\w+$/', $line)) {
				$bg_color = !$bg_color;
				$style = $bg_color ? "background-color: #f8f9fa;" : "background-color: #ffffff;";
				// Cambiar <p> por <div> y ajustar cierre
				echo "<div style='" . $style . "padding: 12px; margin: 4px 0; border-radius: 8px; border-left: 4px solid #4CAF50; word-wrap: break-word; overflow-wrap: break-word;'>"; // Añadir estilos aquí
				echo "<div class='result-item'>";
				echo "<i class='fas fa-check-circle tick-icon'></i>";
				echo "<div class='result-content'>";

				$line_with_forward_slashes = str_replace("\\", "/", $line);
				$url = "https://calentamientoglobalacelerado.net/ebiblio_melilla_riff/" . rawurlencode($line_with_forward_slashes);
				$url = str_replace("%2F", "/", $url);
				echo "<a href='$url' target='_blank'>" . htmlspecialchars($line_with_forward_slashes) . "</a>";

				echo "</div></div></div>"; // Cierre correcto
				$count++;
            } else {
                $bg_color = !$bg_color;
                $style = $bg_color ? "background-color: #f8f9fa;" : "background-color: #ffffff;";
                echo "<div style='padding: 12px; margin: 4px 0; border-radius: 8px; border-left: 4px solid #4CAF50; word-wrap: break-word; overflow-wrap: break-word; " . $style . "'>";
                echo "<div class='result-item'>";
                //echo "<i class='fas fa-folder tick-icon'></i>";
                echo "<div class='result-content'>";
                $line_with_forward_slashes = str_replace("\\", "/", $line);
                echo htmlspecialchars($line_with_forward_slashes) . " <span class='folder-badge'>carpeta</span>";
                echo "</div></div></div>";
            }
        }
    }
 
    $total_count_adjusted = $total_count - 45;
 
    $percentage = $total_count_adjusted > 0 ? ($count / $total_count_adjusted) * 100 : 0;
 
    if ($count > 0) {
        echo "<div style='background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%); color: #1565c0; padding: 15px; margin: 20px 0; border-radius: 10px; text-align: center; border-left: 4px solid #2196f3;'>";
        echo "<strong>🔍 BUSQUEDA: " . htmlspecialchars($search_string) . "</strong>";
        echo "</div>";
        echo "<div class='search-stats'>";
        echo "<h2><i class='fas fa-chart-bar'></i> Coincidencias halladas: " . $count . "<br> (" . number_format($percentage, 2) . "%) de un total aproximado de " . $total_count_adjusted . " archivos</h2>";
        echo "</div>";
    } else {
        echo "<div style='background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%); color: #1565c0; padding: 15px; margin: 20px 0; border-radius: 10px; text-align: center; border-left: 4px solid #2196f3;'>";
        echo "<strong>🔍 BUSQUEDA: " . htmlspecialchars($search_string) . "</strong>";
        echo "</div>";        		
		echo "<div class='no-results'>";
        echo "<h2><i class='fas fa-exclamation-triangle'></i> NO SE HALLARON COINCIDENCIAS EN EL INDICE DEL FONDO</h2>";
        echo "<p><strong>REFORMULE CONSULTA</strong></p>";
        echo "<p>NO utilice nunca TILDES, SIMBOLOS ORTOGRAFICOS ni la letra Ñ</p>";
        echo "<p>Realice una nueva consulta y tenga presente que este buscador solo rastrea el LISTADO (Indice-tesauro) de ficheros ";
        echo "contenidos en el fondo. Valore la exploración con el SISTEMA EXPERTO de inteligencia artificial accediendo desde la web principal del fondo.</p>";
        echo "<p>Para consultas en el interior de los documentos, contacte con el administrador del fondo en la cuenta eurocamsuite[arroba]yahoo.es</p>";
        echo "</div>";
    }
    echo "<br>";
}
?>
    </div>

    <div class="donation">
        <p><strong><u>💝 APOYO AL AUTOR</u></strong></p>
        <p>S . O . S .</p> 
		<p>Este Fondo Documental sobre Melilla y el Rif es un proyecto personal desarrollado y mantenido &uacute;nicamente mediante recursos propios, lo cual limita inevitablemente las capacidades de almacenamiento y hospedaje del material as&iacute; como otros muchos aspectos t&eacute;cnicos y cualitativos del mismo, por ello, si lo considera justo puede colaborar y contribuir al mantenimiento y la mejora del mismo realizando un donativo al autor y administrador del fondo.</p>
        <p>Con este honorable gesto usted contribuye a la continuidad, mejora y mantenimiento de este proyecto.</p>
        
        <form action="https://www.paypal.com/cgi-bin/webscr" method="post">
            <div align="center">
                <input type="hidden" name="cmd" value="_donations" />
                <input type="hidden" name="business" value="eurocamsuite@yahoo.es" />
                <input type="hidden" name="lc" value="ES" />
                <input type="hidden" name="item_name" value="Donativo voluntario al autor del Fondo Documental" />
                <input type="hidden" name="amount" />
                <input type="hidden" name="currency_code" value="EUR" />
                <input type="hidden" name="bn" value="PP-DonationsBF:btn_donateCC_LG.gif:NonHostedGuest" />
                <input type="image" src="https://www.paypal.com/es_ES/ES/i/btn/btn_donateCC_LG.gif" border="0" name="submit" alt="PayPal. La forma r&aacute;pida y segura de pagar en Internet." />
                <img alt="" border="0" src="https://www.paypal.com/es_ES/i/scr/pixel.gif" width="1" height="1" />
            </div>
        </form>
    </div>

    <div class="footer">
        <p><i class='fas fa-server'></i> Proyecto desarrollado y alojado en servidor securizado<br><a href="https://calentamientoglobalacelerado.net">https://calentamientoglobalacelerado.net</a></p>
        <p><i class='fas fa-code'></i> Tecnolog&iacutea propia MARAFd Open Source</p>
        <p><a href="https://calentamientoglobalacelerado.net/MARAFd/" target="_blank">
        <img src="https://calentamientoglobalacelerado.net/MARAFd/img/logo6.gif" class="centered zoom-effect" alt="Logotivo MARAFd" style="width: auto; height: auto; display: block; margin: 0 auto;">
        </a></p>
        <p><i class='fas fa-envelope'></i> info@calentamientoglobalacelerado.net - eurocamsuite@yahoo.es</p>
        <p>Rafael Lomena Varo - 2007 <i class='fas fa-copyright'></i><i class='fas fa-copyright'></i> 2026</p>
    </div>
</div>

</body>
</html>