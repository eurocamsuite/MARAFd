@echo off
echo $ Empaquetado del ecosistema MARAFd desde directorio local ...
echo $  de ecosistema-marafd-servidor.zip

REM refresca listado de archivos para empaquetar
 dir /b /a:-d *.* > ecosistema-marafd-servidor

REM espera un poco antes de seguir
timeout /t 2

REM Comprobar si ecosistema.mar existe
if not exist ecosistema-marafd-servidor (
    echo El archivo ecosistema-marafd-servidor no existe.
    exit /b 1
)

REM Construir la lista de archivos desde ecosistema-marafd-servidor
setlocal EnableDelayedExpansion
set "fileList="
for /f "usebackq delims=" %%a in ("ecosistema-marafd-servidor") do (
    set "fileList=!fileList! %%a"
)
endlocal & set "fileList=%fileList%"

REM Crear el ZIP usando tar (requiere Windows 10 o superior)
REM Incluye también las carpetas css, js e img completas
tar -a -c -f ecosistema-marafd-servidor.zip %fileList% css js img

REM espera un poco antes de seguir
timeout /t 2

if exist D:\_calentamientoglobalacelerado.net\fondo_documental_Melilla_Riff\ecosistema-marafd-servidor.zip (
    echo Archivo ecosistema-marafd-servidor.zip creado correctamente.
) else (
    echo Error al crear el archivo ZIP.
)
