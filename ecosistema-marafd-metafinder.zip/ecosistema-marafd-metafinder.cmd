@echo off
echo $ Empaquetado del ecosistema MARAFd desde directorio local ...
echo $ de ecosistema-marafd-metafinder.zip

REM refresca listado de archivos para empaquetar
 dir /b /a:-d *.* > ecosistema-marafd-metafinder

REM espera un poco antes de seguir
timeout /t 2

REM Comprobar si existe
if not exist ecosistema-marafd-metafinder (
    echo El archivo ecosistema-marafd-metafinder no existe.
    exit /b 1
)

REM Construir la lista de archivos desde ecosistema-marafd-servidor
setlocal EnableDelayedExpansion
set "fileList="
for /f "usebackq delims=" %%a in ("ecosistema-marafd-metafinder") do (
    set "fileList=!fileList! %%a"
)
endlocal & set "fileList=%fileList%"

REM Crear el ZIP usando tar (requiere Windows 10 o superior)
REM Incluye también las carpetas css, js e img completas
tar -a -c -f ecosistema-marafd-metafinder.zip %fileList% css js img

if exist ecosistema-marafd-metafinder.zip (
    echo Archivo ecosistema-marafd-metafinder.zip creado correctamente.
) else (
    echo Error al crear el archivo ZIP.
)
