﻿<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>METABUSQUEDA RAPIDA MARAFd [OpenSource] en Fondos Documentales Digitales Agregados Melilla-Riff & Historia Antigua 01</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 10px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 15px;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }

        .header {
            background: linear-gradient(135deg, #6CAF80 0%, #1E4D12 100%);
            color: white;
            padding: 20px;
            text-align: center;
            border-radius: 12px;
            margin-bottom: 20px;
            box-shadow: 0 5px 20px rgba(76, 175, 80, 0.3);
        }

        .header img {
            width: 100%;
            max-width: 825px;
            height: auto;
            border-radius: 8px;
            transition: transform 0.3s ease;
        }

        .header img:hover {
            transform: scale(1.02);
        }

        .search-section {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            padding: 25px;
            border-radius: 12px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
        }

        .search-section h1 {
            color: #2c3e50;
            margin-bottom: 15px;
            font-size: clamp(1.5rem, 4vw, 2.2rem);
            font-weight: 700;
            text-align: center;
            background: linear-gradient(135deg, #667eea, #764ba2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .search-section h2 {
            color: #34495e;
            margin-bottom: 12px;
            font-size: clamp(0.9rem, 2.5vw, 1.1rem);
            line-height: 1.5;
            background: rgba(255, 255, 255, 0.7);
            padding: 12px;
            border-radius: 8px;
            border-left: 4px solid #3498db;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.05);
        }

        .search-section h3 {
            color: #34495e;
            margin-bottom: 12px;
            font-size: clamp(0.9rem, 2.5vw, 1.1rem);
            line-height: 1.5;
            background: rgba(255, 255, 255, 0.7);
            padding: 12px;
            border-radius: 8px;
            border-left: 4px solid #3498db;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.05);
        }

        .search-section h3::before {
            content: '💡';
            margin-right: 8px;
        }

        form {
            text-align: center;
            margin: 20px 0;
            padding: 20px;
            background: rgba(255, 255, 255, 0.9);
            border-radius: 12px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 15px;
            align-items: center;
        }

        form input[type="text"] {
            padding: 12px 18px;
            font-size: 16px;
            border: 2px solid #e0e0e0;
            border-radius: 25px;
            width: 100%;
            max-width: 400px;
            outline: none;
            transition: all 0.3s ease;
            background: white;
            box-shadow: inset 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        form input[type="text"]:focus {
            border-color: #4CAF50;
            box-shadow: 0 0 15px rgba(76, 175, 80, 0.3);
        }

        form input[type="submit"] {
            padding: 12px 25px;
            font-size: 16px;
            background: linear-gradient(135deg, #4CAF50 0%, #45a049 100%);
            color: white;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 12px rgba(76, 175, 80, 0.3);
            font-weight: 600;
            min-width: 120px;
        }

        form input[type="submit"]:hover {
            background: linear-gradient(135deg, #45a049 0%, #4CAF50 100%);
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(76, 175, 80, 0.4);
        }

        .results {
            background: white;
            border-radius: 12px;
            padding: 15px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .results p {
            padding: 12px;
            margin: 4px 0;
            border-radius: 8px;
            border-left: 4px solid #4CAF50;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        .results a {
            color: #2980b9;
            text-decoration: none;
            font-weight: 500;
            word-wrap: break-word;
        }

        .results a:hover {
            color: #3498db;
        }

        .results hr {
            border: none;
            height: 2px;
            background: linear-gradient(90deg, transparent, #4CAF50, transparent);
            margin: 15px 0;
        }

        .results .separator-line {
            display: none;
        }

        .search-stats {
            background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
            color: white;
            padding: 15px;
            border-radius: 10px;
            text-align: center;
            margin: 15px 0;
            box-shadow: 0 5px 15px rgba(44, 62, 80, 0.3);
        }

        .search-stats h2 {
            margin: 8px 0;
            font-size: clamp(1.1rem, 3vw, 1.5rem);
        }

        .no-results {
            background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
            color: white;
            padding: 20px;
            border-radius: 12px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(231, 76, 60, 0.3);
        }

        .donation {
            background: linear-gradient(135deg, #f39c12 0%, #e67e22 100%);
            color: white;
            padding: 20px;
            border-radius: 12px;
            text-align: center;
            margin: 20px 0;
            box-shadow: 0 5px 20px rgba(243, 156, 18, 0.3);
        }

        .donation p {
            line-height: 1.5;
            margin-bottom: 15px;
            font-size: clamp(0.9rem, 2.5vw, 1rem);
        }

        .donation form {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            padding: 15px;
        }

        .donation input[type="image"] {
            transition: transform 0.3s ease;
            border-radius: 8px;
            max-width: 100%;
            height: auto;
        }

        .donation input[type="image"]:hover {
            transform: scale(1.05);
        }

        .footer {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            color: #2c3e50;
            padding: 20px;
            border-radius: 12px;
            text-align: center;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        }

        .footer p {
            margin: 8px 0;
            line-height: 1.5;
            font-size: clamp(0.9rem, 2.5vw, 1rem);
        }

        .footer a {
            color: #2980b9;
            text-decoration: none;
            word-wrap: break-word;
        }

        .footer a:hover {
            color: #3498db;
        }

        .footer img {
            margin: 10px 0;
            max-width: 100%;
            height: auto;
            transition: transform 0.3s ease;
        }

        .footer img:hover {
            transform: scale(1.05);
        }

        .tick-icon {
            color: #4CAF50;
            margin-right: 8px;
            font-size: 14px;
            flex-shrink: 0;
        }

        .folder-badge {
            background: linear-gradient(135deg, #27ae60 0%, #2ecc71 100%);
            color: white;
            padding: 2px 6px;
            border-radius: 12px;
            font-size: 0.75em;
            font-weight: 600;
            margin-left: 8px;
            white-space: nowrap;
        }

        .source-badge {
            background: linear-gradient(135deg, #3498db 0%, #2980b9 100%);
            color: white;
            padding: 2px 6px;
            border-radius: 12px;
            font-size: 0.7em;
            font-weight: 600;
            margin-left: 8px;
            white-space: nowrap;
        }

        .result-item {
            display: flex;
            align-items: flex-start;
            gap: 8px;
        }

        .result-content {
            flex: 1;
            min-width: 0;
        }

        .section-header {
            background: linear-gradient(135deg, #8e44ad 0%, #9b59b6 100%);
            color: white;
            padding: 12px 20px;
            margin: 20px 0 10px 0;
            border-radius: 8px;
            font-weight: bold;
            text-align: center;
            box-shadow: 0 3px 10px rgba(142, 68, 173, 0.3);
        }

        /* Optimizaciones para móviles */
        @media (max-width: 768px) {
            body {
                padding: 5px;
            }
            
            .container {
                padding: 10px;
                border-radius: 10px;
            }
            
            .header {
                padding: 15px;
            }
            
            .search-section {
                padding: 15px;
            }
            
            .form-group {
                width: 100%;
            }
            
            form {
                padding: 15px;
            }
            
            form input[type="text"] {
                width: 100%;
                margin-bottom: 0;
            }
            
            .results {
                padding: 10px;
            }
            
            .results p {
                padding: 8px;
                font-size: 14px;
            }
            
            .donation {
                padding: 15px;
            }
            
            .footer {
                padding: 15px;
            }
        }

        @media (max-width: 480px) {
            .container {
                margin: 2px;
                padding: 8px;
            }
            
            .header {
                padding: 10px;
            }
            
            .search-section {
                padding: 12px;
            }
            
            .search-section h3 {
                padding: 8px;
                font-size: 0.85rem;
            }
            
            form {
                padding: 10px;
            }
            
            .results p {
                padding: 6px;
                font-size: 13px;
            }
            
            .donation p {
                font-size: 0.85rem;
            }
            
            .footer p {
                font-size: 0.85rem;
            }
        }

        /* Eliminamos animaciones pesadas en móviles */
        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after {
                animation-duration: 0.01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: 0.01ms !important;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <a href="https://calentamientoglobalacelerado.net/MARAFd/">
            <img src="img/logo5.png" alt="METABUSCADOR RAPIDO EN FONDOS DOCUMENTALES AGREGADOS CON TECNOLOGIA MARAFd.net">
        </a>
    </div>

	<div style="text-align:center; padding: 20px;">
	    	<div class="search-section">
		<h2>¡OJO! Debe actualizar antes los índices-tesauros de los fondos documentales agregados a este Metabuscador:<br></h2>
		        <form method="post" style="margin-top: 20px;">
		            <input type="submit" name="actualizar_indices" value="Actualizar tesauros" style="padding: 12px 25px; font-size: 16px; background: linear-gradient(135deg, #4CAF50, #45a049); color: white; border: none; border-radius: 25px; cursor: pointer;">
		        </form>
		</div>

            <?php
            // Manejar acción de actualización cuando se pulse el botón
            if (isset($_POST['actualizar_indices'])) {
                $updated = actualizarIndicesDesdeOrigen(__DIR__ . '/fondos_agregados.csv');
                $last_update = date('d/m/Y H:i:s');
            }

            // Mostrar información de última actualización
            if (isset($updated)) {
                echo '<div style="text-align:center; padding:10px; background:#e8f5e9; border-radius:8px; margin-top:20px;">';
                echo '<p><strong>Última actualización:</strong> ' . htmlspecialchars($last_update) . '</p>';
                echo '<p><strong>Índices actualizados:</strong> ' . htmlspecialchars(implode(', ', $updated)) . '</p>';
                echo '</div>';
            }
            ?>
    </div>	
	
    <div class="search-section">
        <h2><center><a href="https://calentamientoglobalacelerado.net/metafinder/agregar_fondo_marafd.html">Cómo agregar fondos documentales digitales al Metabuscador de <font color="#0080aa"><i>MA</i></font><font color="#dd8080">RA</font><font color="#bb9933">Fd</font></b></a></center></h2>
		<h1><br><b>METABÚSQUEDA RÁPIDA EN INDICES-TESAUROS<br>
		de fondos documentales agregados gestionados con tecnología de código abierto <b><font color="#0080aa"><i>MA</i></font><font color="#dd8080">RA</font><font color="#bb9933">Fd</font></b></h1>
		<h3>MÁXIMO TRES palabras por consulta. EJEMPLOS: <br>MELILLA VIEJA; BRAVO NIETO; 1970; REVIS AKROS; PICAS; AMAZIG; MAPA; BEREBER; DICCIO; ...</h3>
        	<h3>EVITE SIEMPRE el uso de preposiciones, art&iacute;culos u otros conectores lingu&iacute;sticos (EL, LAS, PARA, DESDE, etc.) as&iacute; 
	        como el uso de tildes y/o s&iacute;mbolos ...</h3>
	        <h3>Puede recurrir al uso de ABREVIATURAS para agilizar algunos
	         rastreos: <br>TFG (trabajo fin de grado); TD (tesis doctoral); 1980; ...</h3>
	        <h3>Para hacer b&uacute;squedas precisas en el INTERIOR DE VARIOS DOCUMENTOS de un fondo documental determinado, 
	        consulte con el administrador en eurocamsuite[arroba]yahoo.es ó bien 
	        utilice la opción de BÚSQUEDA CON TECNOLOGÍA GOOGLE ó bien el Sistema Experto MARAFd, accesibles desde la web principal del fondo documental que desee consultar.</h3>

        <form action="" method="post">
            <div class="form-group">
                <input type="text" name="search" size="40" placeholder="ej ANUAL (3 palab./word MAXIMO)">
                <input type="submit" name="submit" value="🔍 Buscar">
            </div>
        </form>
    </div>
	
    <div class="results">
<?php

// Función para actualizar índices desde el origen (versión robusta)
function actualizarIndicesDesdeOrigen($csv_path) {
    $csv_lines = file($csv_path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $base_url = '';
    $file_name = '';
    $updated_files = []; // Array para almacenar archivos actualizados

                foreach ($csv_lines as $line) {
                    if (strpos($line, "'base_url'") !== false) {
                        preg_match("/'base_url' => '(.*?)'/", $line, $match_base);
                        $base_url = trim($match_base[1]);
                    }
                    if (strpos($line, "'file'") !== false) {
                        preg_match("/'file' => '(.*?)'/", $line, $match_file);
                        $file_name = trim($match_file[1]);
                    }

                    if (!empty($base_url) && !empty($file_name)) {
                        $url_completa = rtrim($base_url, '/') . '/' . ltrim($file_name, '/');
                        $contenido = @file_get_contents($url_completa);

                        if ($contenido !== false) {
                            file_put_contents(__DIR__ . '/' . $file_name, $contenido);
                            $updated_files[] = $file_name; // Registrar archivo actualizado
                        }

                        // Resetear variables para siguiente iteración
                        $base_url = '';
                        $file_name = '';
        }
    }
	return $updated_files;
}

// Manejar acción de actualización cuando se pulse el botón
if (isset($_POST['actualizar_indices'])) {
    actualizarIndicesDesdeOrigen(__DIR__ . '/fondos_agregados.csv');
}

?>

<?php
// PROYECTO: MARAFd - GESTION INTELIGENTE DE FONDOS DOCUMENTALES DIGITALES BASADA EN TESAURO                     
// Ecosistema tecnologia: MARAFd (c)(c) 2025
// Proceso en servidor: index.php by MARAFd - TECNOLOGIA PARA LA GESTION DE FONDOS DOCUMENTALES DIGITALES
// Creative Commons Attribution-NonCommercial-ShareAlike 4.0 - 06/02/2025 - Num.reg. 2502060809787          
// OPEN SOURCE SOLUTION by RAFAEL LOMENA VARO - MARAF SOFT 1993 ©© 2026    
// Idea original: Rafael Lomena - MaRaF SOFT
// https://calentamientoglobalacelerado.net/MARAFd/
//
// Program: /metafinder/index.php 
// Program original: finder3.php 
// PHP version: 8.3
// Fecha: 18/06/2025 - REVISION 23/03/2026     
// Autor: Original por ChatGPT, DeepSeek, Claude y autor idea 
// Idea original: Rafael Lomena - MaRaF SOFT
// Ecosistema tecnologia: MARAFd (c)(c) 2026                                
// Descripcion: sistema de búsqueda rápida fonética y simultánea en indices-tesauros de varios fondos documentales y generacion de enlaces dinamicos

// FLUJO DEL PROCESO:
// ACTUALIZACION DE INDICES-TESAUROS
//    indices-tesauros alojados en carpeta 'metafinder' servidor (se copian desde origen (establecida en 'fondos_agregados.csv') a carpeta de index.php
// Se lee entrada de maximo 2 cadenas de texto y se noramlizan los caraceteres para lanzar busqueda en archivos indices-tesauros copiados en misma ruta 
//    Se crea reporte HTML con resultados e hiperenlaces directos a documentos

function normalize($string) {
    $normalized = Normalizer::normalize($string, Normalizer::FORM_D);
    $normalized = preg_replace('/\p{Mn}/u', '', $normalized);
    $normalized = str_replace(['Ń', 'ń'], ['N', 'n'], $normalized);

    // Antes de eliminar caracteres no alfanuméricos, tratar guiones y guiones bajos como separadores.
    // Se sustituyen por espacios para evitar que al eliminar estos símbolos se unan palabras y se
    // forme la secuencia "ll" entre la última y la primera letra de cada palabra, lo que
    // provocaba reemplazos incorrectos en el algoritmo fonético. Por ejemplo, "Rafael-Lomena"
    // pasará a "rafael lomena" en lugar de "rafaellomena".
    $normalized = str_replace(['-', '_'], ' ', $normalized);
    
    // Convertir a minúsculas y eliminar caracteres no alfanuméricos (excepto espacios)
    $normalized = mb_strtolower($normalized);
    $normalized = preg_replace('/[^a-z0-9\s]/', '', $normalized);
    
    // Equivalencia LL → Y (primero para evitar conflictos)
    $normalized = str_replace('ll', 'y', $normalized); // Paso clave
    
    // Manejar equivalencias Q/K
    $normalized = str_replace(['qu', 'q', 'ku'], 'k', $normalized);
    
    // Reducir letras consecutivas duplicadas
    $normalized = preg_replace('/(.)\1+/u', '$1', $normalized);
    
    // Equivalencias fonéticas existentes
    $normalized = str_replace(
        ['v', 'á', 'é', 'í', 'ó', 'ú', 'j', 'h', 'y'],
        ['b', 'a', 'e', 'i', 'o', 'u', 'g', '', 'y'], 
        $normalized
    );
    
    $normalized = preg_replace(
        ['/c([ei])/i', '/z/i', '/g([ei])/i'], 
        ['s$1', 's', 'j$1'], 
        $normalized
    );
    
    return $normalized;
}

function searchInFile($filename, $search_words, $base_url, $source_name) {
    $results = [];
    $count = 0;
    $total_count = 0;
    
    if (!file_exists($filename)) {
        return ['results' => [], 'count' => 0, 'total_count' => 0];
    }
    
    $file_contents = file_get_contents($filename);
    $lines = explode("\n", $file_contents);
    $bg_color = false;
    
    foreach ($lines as $line) {
        $line = trim($line);
        if (preg_match('/\.\w+$/', $line)) {
            $total_count++;
        }
        $normalized_line = normalize($line);
        $found_words = 0;
        foreach ($search_words as $word) {
            if (strpos($normalized_line, $word) !== false) {
                $found_words++;
            }
        }
 
        if ($found_words == count($search_words)) {
            $bg_color = !$bg_color;
            $style = $bg_color ? "background-color: #f8f9fa;" : "background-color: #ffffff;";
            
            $result_html = "";
            
            if (preg_match('/\.\w+$/', $line)) {
                $result_html .= "<div style='" . $style . "padding: 12px; margin: 4px 0; border-radius: 8px; border-left: 4px solid #4CAF50; word-wrap: break-word; overflow-wrap: break-word;'>";
                $result_html .= "<div class='result-item'>";
                $result_html .= "<i class='fas fa-check-circle tick-icon'></i>";
                $result_html .= "<div class='result-content'>";

                $line_with_forward_slashes = str_replace("\\", "/", $line);
                $url = $base_url . rawurlencode($line_with_forward_slashes);
                $url = str_replace("%2F", "/", $url);
                $result_html .= "<a href='$url' target='_blank'>" . htmlspecialchars($line_with_forward_slashes) . "</a>";
                $result_html .= "<span class='source-badge'>" . $source_name . "</span>";

                $result_html .= "</div></div></div>";
                $count++;
            } else {
                $result_html .= "<div style='padding: 12px; margin: 4px 0; border-radius: 8px; border-left: 4px solid #4CAF50; word-wrap: break-word; overflow-wrap: break-word; " . $style . "'>";
                $result_html .= "<div class='result-item'>";
                $result_html .= "<div class='result-content'>";
                $line_with_forward_slashes = str_replace("\\", "/", $line);
                $result_html .= htmlspecialchars($line_with_forward_slashes) . " <span class='folder-badge'>carpeta</span>";
                $result_html .= "<span class='source-badge'>" . $source_name . "</span>";
                $result_html .= "</div></div></div>";
            }
            
            $results[] = $result_html;
        }
    }
    
    return ['results' => $results, 'count' => $count, 'total_count' => $total_count];
}

if (isset($_POST['submit'])) {
    $search_string = $_POST['search'];
    $normalized_search_string = normalize($search_string);
    $search_words = mb_split('\s+', $normalized_search_string);
    
    // Modificación para manejar palabras en plural
    $search_words = array_map(function($word) {
        // Solo procesar palabras con más de 4 caracteres que terminen en 's'
        if (mb_strlen($word) > 4 && mb_substr($word, -1) === 's') {
            return mb_substr($word, 0, -1);
        }
        return $word;
    }, $search_words);
    
    $search_words = array_slice($search_words, 0, 3);

    // CODIGO que carga de tesauros leidos a partir de archivo 'fondos_agregados.csv' 
	// y URLs base para implementar METABUSQUEDA
	
		$files_config = [];                                             // 1) array destino
		$pathCSV      = __DIR__ . '/fondos_agregados.csv';              // 2) ruta del fichero

		$raw = file_get_contents($pathCSV);                             // 3) leer todo el archivo
		if ($raw === false) {
			throw new RuntimeException("No se pudo leer $pathCSV");
		}

		/*
		 * 4)  Extraer cada bloque entre corchetes […] que representa un registro.
		 *     La ‘s’ en el modificador /s permite que ‘.’ abarque saltos de línea.
		 */
		if (preg_match_all('/\[(.*?)\]/s', $raw, $bloques)) {
			foreach ($bloques[1] as $bloque) {

				// 5) Para cada bloque localizamos todas las parejas 'clave' => 'valor'
				if (preg_match_all("/'([^']+)'\s*=>\s*'([^']+)'/", $bloque, $campos, PREG_SET_ORDER)) {

					$temp = [];                                         // array temporal
					foreach ($campos as $campo) {
						$temp[$campo[1]] = $campo[2];                   // ej. $temp['file'] = '…'
					}

					// 6) Sólo añadimos registros completos (las cuatro claves necesarias)
					if (isset($temp['file'], $temp['base_url'], $temp['source_name'], $temp['title'])) {
						$files_config[] = [
							'file'        => $temp['file'],
							'base_url'    => $temp['base_url'],
							'source_name' => $temp['source_name'],
							'title'       => $temp['title']
						];
					}
				}
			}
		}

    $total_count = 0;
    $total_results = 0;
    $all_results = [];
    
    echo "<hr style='border: none; height: 2px; background: linear-gradient(90deg, transparent, #4CAF50, transparent); margin: 20px 0;' />";
    
    // Buscar en cada archivo
    foreach ($files_config as $config) {
        $search_result = searchInFile($config['file'], $search_words, $config['base_url'], $config['source_name']);
        
        if (!empty($search_result['results'])) {
            echo "<div class='section-header'>";
            echo "<i class='fas fa-folder-open'></i> " . $config['title'];
            echo " <span style='font-size: 0.8em;'>(" . $search_result['count'] . " resultados)</span>";
            echo "</div>";
            
            foreach ($search_result['results'] as $result) {
                echo $result;
            }
        }
        
        $total_results += $search_result['count'];
        $total_count += $search_result['total_count'];
    }
    
    // Ajuste del total de archivos (restando 45 como en el código original)
    $total_count_adjusted = $total_count - 45;
    
    $percentage = $total_count_adjusted > 0 ? ($total_results / $total_count_adjusted) * 100 : 0;
 
    if ($total_results > 0) {
        echo "<div style='background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%); color: #1565c0; padding: 15px; margin: 20px 0; border-radius: 10px; text-align: center; border-left: 4px solid #2196f3;'>";
        echo "<strong>🔍 BUSQUEDA: " . htmlspecialchars($search_string) . "</strong>";
        echo "</div>";
        echo "<div class='search-stats'>";
        echo "<h2><i class='fas fa-chart-bar'></i> Coincidencias totales halladas en fondos: " . $total_results . "<br> (" . number_format($percentage, 2) . "%) de un total aproximado de " . $total_count_adjusted . " archivos</h2>";
        echo "</div>";
    } else {
        echo "<div style='background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%); color: #1565c0; padding: 15px; margin: 20px 0; border-radius: 10px; text-align: center; border-left: 4px solid #2196f3;'>";
        echo "<strong>🔍 BUSQUEDA: " . htmlspecialchars($search_string) . "</strong>";
        echo "</div>";
        echo "<div class='no-results'>";
        echo "<h2><i class='fas fa-exclamation-triangle'></i> NO SE HALLARON COINCIDENCIAS EN LOS INDICES DEL FONDO</h2>";
        echo "<p><strong>REFORMULE CONSULTA</strong></p>";
        echo "<p>NO utilice nunca TILDES, SIMBOLOS ORTOGRAFICOS ni la letra Ñ</p>";
        echo "<p>Realice una nueva consulta y tenga presente que este buscador solo rastrea el LISTADO (Indice-tesauro) de ficheros ";
        echo "contenidos en el fondo. Valore la exploración con el SISTEMA EXPERTO de inteligencia artificial accediendo desde la web principal del fondo.</p>";
        echo "<p>Para consultas en el interior de los documentos, contacte con el administrador del fondo en la cuenta eurocamsuite[arroba]yahoo.es</p>";
        echo "</div>";
    }
    echo "<br>";
}
?>
    </div>

    <div class="donation">
        <p><strong><u>💝 APOYO AL AUTOR</u></strong></p>
        <p>El buscador METAFINDER y el Fondo Documental sobre Melilla y el Rif forman parte de un proyecto personal desarrollado y mantenido &uacute;nicamente mediante recursos propios, lo cual limita las capacidades de almacenamiento y hospedaje del material as&iacute; como otros muchos aspectos t&eacute;cnicos y cualitativos del mismo, por ello, si lo considera justo puede colaborar y contribuir al mantenimiento y mejora del mismo realizando un donativo al autor y administrador del fondo.</p>
        <p>Con este honorable gesto usted contribuye a la continuidad, mejora y mantenimiento de este proyecto.</p>
        
        <form action="https://www.paypal.com/cgi-bin/webscr" method="post">
            <div align="center">
                <input type="hidden" name="cmd" value="_donations" />
                <input type="hidden" name="business" value="eurocamsuite@yahoo.es" />
                <input type="hidden" name="lc" value="ES" />
                <input type="hidden" name="item_name" value="Donativo voluntario al autor del Fondo Documental" />
                <input type="hidden" name="amount" />
                <input type="hidden" name="currency_code" value="EUR" />
                <input type="hidden" name="bn" value="PP-DonationsBF:btn_donateCC_LG.gif:NonHostedGuest" />
                <input type="image" src="https://www.paypal.com/es_ES/ES/i/btn/btn_donateCC_LG.gif" border="0" name="submit" alt="PayPal. La forma r&aacute;pida y segura de pagar en Internet." />
                <img alt="" border="0" src="https://www.paypal.com/es_ES/i/scr/pixel.gif" width="1" height="1" />
            </div>
        </form>
    </div>
	
    <div class="footer">
        <p><i class='fas fa-server'></i> Proyecto desarrollado y alojado en servidor securizado<br><a href="https://calentamientoglobalacelerado.net">https://calentamientoglobalacelerado.net</a></p>
        <p><i class='fas fa-code'></i> Tecnolog&iacutea propia MARAFd Open Source</p>
        <p><a href="https://calentamientoglobalacelerado.net/MARAFd/" target="_blank">
        <img src="https://calentamientoglobalacelerado.net/MARAFd/img/logo6.gif" class="centered zoom-effect" alt="Logotivo MARAFd" style="width: auto; height: auto; display: block; margin: 0 auto;">
        </a></p>
        <p><i class='fas fa-envelope'